import 'package:flutter/services.dart';

MethodChannel channel = const MethodChannel('cometchat');
EventChannel eventStreamChannel =
    const EventChannel('cometchat_message_stream');
EventChannel typingStream = const EventChannel('cometchat_typing_stream');

class CometChatReceiverType {
  static const String user = 'user';
  static const String group = 'group';
}

class CometChatMessageType {
  static const String image = 'image';
  static const String video = 'video';
  static const String audio = 'audio';
  static const String file = 'file';
  static const String text = 'text';
  static const String custom = 'custom';
  static const String assistant = "assistant";
  static const String toolResult = "tool-result";
  static const String toolArguments = "tool-arguments";
  static const String runStarted = "run_started";
}

class CometChatGroupType {
  static const String private = 'private';
  static const String public = 'public';
  static const String password = 'password';
}

class CometChatConversationType {
  static const String user = 'user';
  static const String group = 'group';
}

class CometChatUserStatus {
  static const String online = 'online';
  static const String offline = 'offline';
}

class CometChatMessageCategory {
  static const String message = 'message';
  static const String action = 'action';
  static const String call = 'call';
  static const String custom = 'custom';
  static const String interactive = 'interactive';
  static const String categoryAgentic = "agentic";
  static const String streamMessage = "streamMessage";
}

class CometChatMemberScope {
  static const String admin = 'admin';
  static const String moderator = 'moderator';
  static const String participant = 'participant';
}

class CometChatCallType {
  static const String audio = 'audio';
  static const String video = 'video';
}

class CometChatCallStatus {
  static const String initiated = 'initiated';
  static const String ongoing = 'ongoing';
  static const String unanswered = 'unanswered';
  static const String rejected = 'rejected';
  static const String busy = 'busy';
  static const String cancelled = 'cancelled';
  static const String ended = 'ended';
}

class CometChatWSState {
  static const String connected = 'connected';
  static const String connecting = 'connecting';
  static const String disconnected = 'disconnected';
  static const String featureThrottled = 'featureThrottled';
}

class CometChatSubscriptionType {
  static const String none = 'none';
  static const String allUsers = 'allUsers';
  static const String roles = 'roles';
  static const String friends = 'friends';
}

class CometChatBlockedUsersDirection {
  static const String directionBlockedByMe = "blockedByMe";
  static const String directionHasBlockedMe = "hasBlockedMe";
  static const String directionBoth = "both";
}

class CometChatReceiptType {
  static const String delivered = "delivered";
  static const String read = "read";
  static const String deliveredToAll = "deliveredToAll";
  static const String readByAll = "readByAll";
}

class ConversationType {
  static const user = "user";
  static const group = "group";
}

class ErrorCode {
  static const errorUnhandledException = "ERROR_UNHANDLED_EXCEPTION";
  static const errorUserNotLoggedIn = "ERROR_USER_NOT_LOGGED_IN";
  static const errorInvalidReceiverId = "ERROR_INVALID_RECEIVER_ID";
  static const errorInvalidReceiverType = "ERROR_INVALID_RECEIVER_TYPE";
  static const errorEmptyAskBotQuestion = "ERROR_EMPTY_QUESTION";
  static const errorEmptyBotID = "ERROR_EMPTY_BOT_ID";
  static const errorEmptyFeature = "ERROR_EMPTY_FEATURE";
  static const errorInvalidTimezone = "ERROR_INVALID_TIMEZONE";
}

class ErrorMessage {
  static const errorMessageUserNotLoggedIn =
      "Please log in to CometChat before calling this method";
  static const errorMessageInvalidReceiverId =
      "Invalid Receiver ID. The receiver ID cannot be null or empty";
  static const errorEmptyFeature =
      "Feature ID cannot be null or empty, Please provide a valid Feature ID";
  static const errorMessageInvalidReceiverType =
      "Invalid Receiver Type. Please provide a valid Receiver type";
  static const errorEmptyAskBotQuestion = "Question cannot be null or empty";
  static const errorEmptyBotID =
      "BotID cannot be null or empty, Please provide a valid Bot ID";
  static const errorInvalidEmptyTimezone = "Timezone cannot be null or empty";
}

class InteractionGoalType {
  static const anyAction = "anyAction";
  static const anyOf = "anyOf";
  static const allOf = "allOf";
  static const none = "none";
}

class ReactionAction {
  static const String reactionAdded = 'added';
  static const String reactionRemoved = 'removed';
}

class AgenticKeys {
  static const String keyAgenticRunId = "runId";
  static const String keyAgenticThreadId = "threadId";
  static const String keyAgenticText = "text";
  static const String keyAgenticToolCalls = "toolCalls";

  // AI Tool Call related constants
  static const String keyToolCallId = "id";
  static const String keyToolCallType = "type";
  static const String keyToolCallDisplayName = "displayName";
  static const String keyToolCallExecutionText = "executionText";
  static const String keyToolCallFunction = "function";

  // AI Tool Call Function related constants
  static const String keyToolCallFunctionName = "name";
  static const String keyToolCallFunctionArguments = "arguments";
  static const String keyAgenticToolCallId = "toolCallId";
  static const String keyWithParent = "withParent";

  static const String runStarted = "run_started";
  static const String textMessageStart = "text_message_start";
  static const String textMessageContent = "text_message_content";
  static const String textMessageEnd = "text_message_end";
  static const String runFinished = "run_finished";
  static const String toolCallStart = "tool_call_start";
  static const String toolCallEnd = "tool_call_end";
  static const String toolCallResult = "tool_call_result";
  static const String toolCallArgs = "tool_call_args";
}
