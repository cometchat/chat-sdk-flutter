package com.cometchat.cometchat_sdk

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.NonNull
import com.cometchat.chat.constants.CometChatConstants
import com.cometchat.chat.core.AppSettings
import com.cometchat.chat.core.BannedGroupMembersRequest
import com.cometchat.chat.core.BlockedUsersRequest
import com.cometchat.chat.core.Call
import com.cometchat.chat.core.CometChat
import com.cometchat.chat.core.CometChat.CallbackListener
import com.cometchat.chat.core.CometChatNotifications
import com.cometchat.chat.core.ConversationsRequest
import com.cometchat.chat.core.GroupMembersRequest
import com.cometchat.chat.core.GroupsRequest
import com.cometchat.chat.core.MessagesRequest
import com.cometchat.chat.core.ReactionsRequest
import com.cometchat.chat.core.UsersRequest
import com.cometchat.chat.enums.AttachmentType
import com.cometchat.chat.enums.ModerationStatus
import com.cometchat.chat.enums.PushPlatforms
import com.cometchat.chat.exceptions.CometChatException
import com.cometchat.chat.models.AIAssistantBaseEvent
import com.cometchat.chat.models.AIAssistantContentReceivedEvent
import com.cometchat.chat.models.AIAssistantMessage
import com.cometchat.chat.models.AIAssistantMessageEndedEvent
import com.cometchat.chat.models.AIAssistantRunFinishedEvent
import com.cometchat.chat.models.AIAssistantRunStartedEvent
import com.cometchat.chat.models.AIAssistantToolArgumentEvent
import com.cometchat.chat.models.AIAssistantToolEndedEvent
import com.cometchat.chat.models.AIAssistantToolResultEvent
import com.cometchat.chat.models.AIAssistantToolStartedEvent
import com.cometchat.chat.models.AIToolArgumentMessage
import com.cometchat.chat.models.AIToolResultMessage
import com.cometchat.chat.models.Action
import com.cometchat.chat.models.Attachment
import com.cometchat.chat.models.BaseMessage
import com.cometchat.chat.models.Conversation
import com.cometchat.chat.models.ConversationUpdateSettings
import com.cometchat.chat.models.CustomMessage
import com.cometchat.chat.models.FlagDetail
import com.cometchat.chat.models.FlagReason
import com.cometchat.chat.models.Group
import com.cometchat.chat.models.GroupMember
import com.cometchat.chat.models.Interaction
import com.cometchat.chat.models.InteractionGoal
import com.cometchat.chat.models.InteractionReceipt
import com.cometchat.chat.models.InteractiveMessage
import com.cometchat.chat.models.MediaMessage
import com.cometchat.chat.models.Reaction
import com.cometchat.chat.models.MessageReceipt
import com.cometchat.chat.models.MutedConversation
import com.cometchat.chat.models.NotificationPreferences
import com.cometchat.chat.models.PushPreferences
import com.cometchat.chat.models.ReactionCount
import com.cometchat.chat.models.ReactionEvent
import com.cometchat.chat.models.TextMessage
import com.cometchat.chat.models.TransientMessage
import com.cometchat.chat.models.TypingIndicator
import com.cometchat.chat.models.UnmutedConversation
import com.cometchat.chat.models.User
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.Serializable
import java.sql.Time
import java.util.Arrays
import java.util.TimeZone

/** CometchatPlugin */
class CometchatPlugin : FlutterPlugin, MethodCallHandler, EventChannel.StreamHandler {
    private val TAG = javaClass.simpleName
    /// The MethodChannel that will the communication between Flutter and native Android
    ///
    /// This local reference serves to register the plugin with the Flutter Engine and unregister it
    /// when the Flutter Engine is detached from the Activity
    private lateinit var channel: MethodChannel
    private lateinit var messageStream: EventChannel
    private lateinit var typingStream : EventChannel
    private val messageRequestMap: MutableMap<String, MessagesRequest> = mutableMapOf()
    private val conversationRequestMap: MutableMap<String, ConversationsRequest> = mutableMapOf()
    private val userRequestMap: MutableMap<String, UsersRequest> = mutableMapOf()
    private val groupMemberRequestMap: MutableMap<String, GroupMembersRequest> = mutableMapOf()
    private val groupRequestMap: MutableMap<String, GroupsRequest> = mutableMapOf()
    private val bannedGroupMemberRequestMap: MutableMap<String, BannedGroupMembersRequest> = mutableMapOf()
    private val blockedUsersRequestMap: MutableMap<String, BlockedUsersRequest> = mutableMapOf()
    private val reactionRequestMap: MutableMap<String, ReactionsRequest> = mutableMapOf()

    private var counter:Int = 0

    private  var messageStreamSink : EventChannel.EventSink? = null
    private  var aiStreamSink : EventChannel.EventSink? = null
    private  var typingStreamSink : EventChannel.EventSink? = null
    private lateinit var context: Context

    private val listenerID:String = "CALL_LISTENER_ID" //Call-SDK-Changes

    override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        context = flutterPluginBinding.applicationContext
        channel = MethodChannel(flutterPluginBinding.binaryMessenger, "cometchat")
        channel.setMethodCallHandler(this)

        messageStream = EventChannel(flutterPluginBinding.binaryMessenger, "cometchat_message_stream")
        messageStream.setStreamHandler(this)

        typingStream = EventChannel(flutterPluginBinding.binaryMessenger, "cometchat_typing_stream")
        typingStream.setStreamHandler(this)
    }

    override fun onMethodCall(@NonNull call: MethodCall, @NonNull result: Result) {
        when (call.method) {
            "init" -> initializeCometChat(call, result)
            "createUser" -> createUser(call, result)
            "loginWithApiKey" -> loginWithApiKey(call, result)
            "loginWithAuthToken" -> loginWithAuthToken(call, result)
            "logout" -> logout(result)
            "getLoggedInUser" -> getLoggedInUser(result)
            "getUser" -> getUser(call, result)
            "sendMessage" -> sendMessage(call, result)
            "sendMediaMessage" -> sendMediaMessage(call, result)
            "sendCustomMessage" -> sendCustomMessage(call, result)
            "fetchPreviousMessages" -> fetchPreviousMessages(call, result)
            "fetchNextConversations" -> fetchNextConversations(call, result)
            "getConversation" -> getConversation(call, result)
            //"getConversationFromMessage" -> getConversationFromMessage(call, result)
            "deleteMessage" -> deleteMessage(call, result)
            "createGroup" -> createGroup(call, result)
            "joinGroup" -> joinGroup(call, result)
            "leaveGroup" -> leaveGroup(call, result)
            "deleteGroup" -> deleteGroup(call, result)
            "fetchNextGroupMembers" -> fetchNextGroupMembers(call, result)
            "fetchNextGroups" -> fetchNextGroups(call, result)
            "registerTokenForPushNotification" -> registerTokenForPushNotification(call, result)
            "getUnreadMessageCount" -> getUnreadMessageCount(result)
            "markAsRead" -> markAsRead(call, result)
            "callExtension" -> callExtension(call, result)
            "blockUsers" -> blockUsers(call, result)
            "unblockUsers" -> unblockUsers(call, result)
            "fetchBlockedUsers" -> fetchBlockedUsers(call, result)
            "fetchUsers" -> fetchUsers(call, result)
            "startTyping" -> startTyping(call, result)
            "endTyping" -> endTyping(call, result)
            "fetchNextMessages" -> fetchNextMessages(call, result)
            "getUnreadMessageCountForGroup"->getUnreadMessageCountForGroup(call,result)
            "getUnreadMessageCountForAllUsers"->getUnreadMessageCountForAllUsers(call,result)
            "getUnreadMessageCountForAllGroups"->getUnreadMessageCountForAllGroups(call,result)
            "markAsDelivered"->markAsDelivered(call,result)
            "getMessageReceipts"->getMessageReceipts(call,result)
            "editMessage"->editMessage(call,result)
            "deleteConversation"->deleteConversation(call,result)
            "sendTransientMessage"->sendTransientMessage(call,result)
            "getOnlineUserCount"->getOnlineUserCount(result)
            "updateUser"->updateUser(call,result)
            "updateCurrentUserDetails"->updateCurrentUserDetails(call,result)
            "getGroup"->getGroup(call,result)
            "getOnlineGroupMemberCount"->getOnlineGroupMemberCount(call,result)
            "updateGroup"->updateGroup(call,result)
            "addMembersToGroup"->addMembersToGroup(call,result)
            "kickGroupMember"->kickGroupMember(call,result)
            "banGroupMember"->banGroupMember(call,result)
            "unbanGroupMember"->unbanGroupMember(call,result)
            "updateGroupMemberScope"->updateGroupMemberScope(call,result)
            "transferGroupOwnership"->transferGroupOwnership(call,result)
            "fetchBlockedGroupMembers"->fetchBlockedGroupMembers(call,result)
            "tagConversation"->tagConversation(call,result)
            "connect"->connect(result)
            "disconnect"->disconnect(result)
            "connectNew"->connectNew(result)
            "disconnectNew"->disconnectNew(result)
            "getLastDeliveredMessageId"->getLastDeliveredMessageId(call ,result)
            "getConnectionStatus"->getConnectionStatus(result)
            "getUserAuthToken"->getUserAuthToken(result)
            "initiateCall"->initiateCall(call, result)
            "acceptCall"->acceptCall(call, result)
            "rejectCall"->rejectCall(call, result)
            "endCall"->endCall(call, result)
            "getActiveCall"->getActiveCall(result)
            "clearActiveCall"->clearActiveCall(result)
            "ping"->ping(result)
            "isExtensionEnabled"->isExtensionEnabled(call,result)
            "setSource"->setSource(call, result)
            "getSmartReplies"->getSmartReplies(call, result)
            "setPlatformParams"->setPlatformParams(call, result)
            "getConversationStarter"->getConversationStarter(call, result)
            "setDemoMetaInfo"->setDemoMetaInfo(call, result)
            "getConversationSummary"->getConversationSummary(call, result)
            "isAIFeatureEnabled"->isAIFeatureEnabled(call, result)
            "askBot"->askBot(call, result)
            "markAsUnread" -> markAsUnread(call, result)
            "sendInteractiveMessage"->sendInteractiveMessage(call, result)
            "markAsInteracted"->markAsInteracted(call, result)
            "addReaction"->addReaction(call, result)
            "removeReaction"->removeReaction(call, result)
            "fetchPreferences"-> fetchPreferences(call, result)
            "updatePreferences"-> updatePreferences(call, result)
            "resetPreferences"-> resetPreferences(call, result)
            "getMutedConversations"-> getMutedConversations(call, result)
            "muteConversations"-> muteConversations(call, result)
            "unmuteConversations"-> unmuteConversations(call, result)
            "registerPushToken"-> registerPushToken(call, result)
            "unregisterPushToken"-> unregisterPushToken(call, result)
            "fetchNextAndPreviousForReactionsRequest" -> fetchNextAndPreviousForReactionsRequest(call, result)
            "getConversationUpdateSettings" -> getConversationUpdateSettings(call, result)
            "updateTimezone"-> updateTimezone(call, result)
            "getTimezone"-> getTimezone(call, result)
            "createGroupWithMembers" -> createGroupWithMembers(call, result)
            "getMessageDetails" -> getMessageDetails(call, result)
            "getFlagReasons" -> getFlagReasons(call, result)
            "flagMessage" -> flagMessage(call, result)
            "markConversationAsDelivered"->markConversationAsDelivered(call,result)
            "markConversationAsRead"->markConversationAsRead(call,result)
            "markMessageAsUnread" -> markMessageAsUnread(call, result)
            else -> result.notImplemented()
        }
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
        if(arguments != null){
            if(arguments as Int == 1){
                messageStreamSink = events
            }else if(arguments as Int == 2){
                typingStreamSink  = events
            }
        }
        addMessageListener()
        addUserListener()
        addGroupListener()
        addLoginListener()
        addConnectionListener()
        addCallListener() //Call-SDK-Changes
        addAIAssistantListener()
    }

    override fun onCancel(arguments: Any?) {
        if(arguments != null){
            if(arguments as Int == 1){
                messageStreamSink = null
            }else if(arguments as Int == 2){
                typingStreamSink  = null
            }
        }
    }

    private fun getUser(call: MethodCall, result: Result) {
        val uid: String = call.argument<String>("uid").toString()

        CometChat.getUser(uid, object : CallbackListener<User?>() {
            override fun onSuccess(user: User?) {
                result.success(user?.let { getUserMap(user) })
            }

            override fun onError(e: CometChatException) {
                result.error(e.code,e.message,e.details)
            }
        })
    }

    // CometChat functions
    private fun initializeCometChat(call: MethodCall, result: Result) {
        val appID: String = call.argument("appId") ?: ""
        val region: String = call.argument("region") ?: ""
        val adminHost: String = call.argument("adminHost") ?: ""
        val clientHost: String = call.argument("clientHost") ?: ""
        val subscriptionType: String = call.argument("subscriptionType") ?: "allUsers"
        val roles: List<String> = call.argument("roles")?: emptyList()
        val autoEstablishSocketConnection: Boolean = call.argument("autoEstablishSocketConnection") ?: true
        val sdkVersion:String =  call.argument("sdkVersion") ?: Utils().getSDKVersion()
        val platform :String =  call.argument("platform") ?: Utils().getPlatform()
        var appBuilder: AppSettings.AppSettingsBuilder =  AppSettings.AppSettingsBuilder()

        if (region.isNotEmpty()) appBuilder = appBuilder.setRegion(region)
        if (adminHost.isNotEmpty()) appBuilder = appBuilder.overrideAdminHost(adminHost)
        if (clientHost.isNotEmpty()) appBuilder = appBuilder.overrideClientHost(clientHost)

        when (subscriptionType) {
            "none" -> Log.i(TAG, "NONE")
            "allUsers" -> {
                appBuilder = appBuilder.subscribePresenceForAllUsers()}
            "roles" -> {
                appBuilder = appBuilder.subcribePresenceForRoles(roles)
            }
            "friends" ->{
                appBuilder = appBuilder.subscribePresenceForFriends()
            }
            else -> { // Note the block
                appBuilder = appBuilder.subscribePresenceForAllUsers()
            }
        }

        setMetaInfo()

        appBuilder = appBuilder.autoEstablishSocketConnection(autoEstablishSocketConnection)
        val appSetting = appBuilder.build()

        CometChat.init(context, appID, appSetting, object : CallbackListener<String>() {
            override fun onSuccess(successString: String?) {
                Log.d("initializeCometChat", "Initialization completed successfully")
                CometChat.setPlatformParams(platform, sdkVersion)
                result.success(successString)
            }

            override fun onError(e: CometChatException) {
                Log.d("initializeCometChat", "Initialization failed with exception: " + e.message)
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun createUser(call: MethodCall, result: Result) {
        val apiKey: String = call.argument("apiKey") ?: ""
        val uid: String = call.argument("uid") ?: ""
        val name: String = call.argument("name") ?: ""
        val avatar: String? = call.argument("avatar")
        val tags: List<String>? = call.argument("tags")
        val link: String? = call.argument("link")
        val metadata: String? = call.argument("metadata")
        val statusMessage: String? = call.argument("statusMessage")
        val role: String? = call.argument("role")
        val blockedByMe: Boolean? = call.argument("blockedByMe")
        val hasBlockedMe: Boolean? = call.argument("hasBlockedMe")
        val lastActiveAt: Long? = call.argument("lastActiveAt")
        val status: String? = call.argument("status")

        val user = User()
        if(uid.isNotEmpty())user.uid = uid
        if(name.isNotEmpty())user.name = name
        if(avatar!=null)user.avatar = avatar
        if(link!=null)user.link = link
        if(metadata!=null) user.metadata = JSONObject(metadata)
        if(tags!=null) user.tags = tags
        if(statusMessage!=null)user.statusMessage = statusMessage
        if(role!=null)user.role = role
        if(blockedByMe!=null)user.isBlockedByMe = blockedByMe
        if(hasBlockedMe!=null)user.isHasBlockedMe = hasBlockedMe
        if(lastActiveAt!=null)user.lastActiveAt = lastActiveAt
        if (status!=null) {
            if(status.equals("online" ,ignoreCase = true)){
                user.status = CometChatConstants.USER_STATUS_ONLINE;
            }else{
                user.status = CometChatConstants.USER_STATUS_OFFLINE
            }

        }

        CometChat.createUser(user, apiKey, object : CallbackListener<User>() {
            override fun onSuccess(user: User) {
                Log.d("createUser", user.toString())
                result.success(getUserMap(user))
            }

            override fun onError(e: CometChatException) {
                Log.e("createUser", e.message ?: "Messed up")
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun loginWithApiKey(call: MethodCall, result: Result) {
        val uid: String = call.argument("uid") ?: ""
        val apiKey: String = call.argument("apiKey") ?: ""
        CometChat.login(uid, apiKey, object : CallbackListener<User>() {
            override fun onSuccess(user: User) {
                Log.d("login", "Login Successful : $user")
                result.success(getUserMap(user))
            }
            override fun onError(e: CometChatException) {
                Log.e("login", "Login failed with exception: " + e.message)
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun loginWithAuthToken(call: MethodCall, result: Result) {
        val authToken: String = call.argument("authToken") ?: ""
        CometChat.login(authToken, object : CallbackListener<User>() {
            override fun onSuccess(user: User) {
                Log.d("login", "Login Successful : $user")
                result.success(getUserMap(user))
            }
            override fun onError(e: CometChatException) {
                Log.e("login", "Login failed with exception: " + e.message)
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun logout(result: Result) {
        CometChat.logout(object : CallbackListener<String>() {
            override fun onSuccess(m: String?) {
                Log.d("logout", "Logout completed successfully$m")
                result.success("User logout successfully")
            }
            override fun onError(e: CometChatException) {
                Log.e("logout", "Logout failed with exception: " + e.message)
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun getLoggedInUser(result: Result) {
        val user: User? = CometChat.getLoggedInUser()
        result.success(user?.let { getUserMap(it) })
    }

    private fun sendMessage(call: MethodCall, result: Result) {
        val receiverID: String = call.argument("receiverId") ?: ""
        val messageText: String = call.argument("messageText") ?: ""
        val muid: String = call.argument("muid") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val tags: List<String> = call.argument("tags") ?: emptyList()
        //val metadata: Map<String , Any > = call.argument("metadata") ?: mapOf()
        val metadata: String = call.argument("metadata") ?: ""
        Log.d("Android", "received metadata = $metadata")
        val quotedMessageId: Long = call.getLongArg("quotedMessageId")

        val textMessage = TextMessage(receiverID, messageText, receiverType)

        if(metadata.isNotEmpty()){
            textMessage.metadata = JSONObject(metadata)
        }

        if(muid.isNotEmpty()) {
            textMessage.muid = muid
        }

        if (parentMessageId > 0) textMessage.parentMessageId = parentMessageId

        if(tags.isNotEmpty()) textMessage.tags =  tags

        if (quotedMessageId > 0) textMessage.quotedMessageId = quotedMessageId

        CometChat.sendMessage(textMessage, object : CallbackListener<TextMessage>() {
            override fun onSuccess(message: TextMessage) {
                Log.d("sendMessage", "Message sent metadata=->  ${message.metadata}")
                result.success(getMessageMap(message))
            }

            override fun onError(e: CometChatException) {
                Log.e("sendMessage", "Message sending failed with exception: " + e.message)
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun getMetaDataRecursively(metadata : Map<String , Any > ): JSONObject{
        val customData=JSONObject()
        for ((k, v) in metadata) {
            var value:Any;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if(v!=null){
                    Log.d("getMetaDataRecursively", "$k with $v datatype ${v::class.java.typeName}")
                }
                else{
                    Log.d("getMetaDataRecursively", "$k with $v datatype $v")
                }
            }else{
                Log.d("getMetaDataRecursively", "version issue")
            }
            if(v!=null &&  (v is Map<*, *> )){
                value =   getMetaDataRecursively(v as Map<String,Any >);
            }else{
                value = v;
            }
            customData.put(k,v)
        }
        return  customData;
    }

    private fun getMessageMap(message: BaseMessage?, methodName : String = ""): HashMap<String, Any?>? {
        if (message == null) return null
        val metaData: String? = if(message.metadata != null){
            message.metadata.toString()
        }else{
            null
        }
        val map: HashMap<String, Any?> = hashMapOf(
            "flutterMap" to "BaseMessage",
            "id" to message.id,
            "muid" to message.muid,
            "sender" to getUserMap(message.sender),
            "receiver" to when (message.receiver) {
                is User -> getUserMap(message.receiver as User)
                is Group -> getGroupMap(message.receiver as Group)
                else -> null
            },
            "receiverUid" to message.receiverUid,
            "type" to message.type,
            "receiverType" to message.receiverType,
            "category" to message.category,
            "sentAt" to message.sentAt,
            "deliveredAt" to message.deliveredAt,
            "readAt" to message.readAt,
            "metadata" to metaData ,
            "readByMeAt" to message.readByMeAt,
            "deliveredToMeAt" to message.deliveredToMeAt,
            "deletedAt" to message.deletedAt,
            "editedAt" to message.editedAt,
            "deletedBy" to message.deletedBy,
            "editedBy" to message.editedBy,
            "updatedAt" to message.updatedAt,
            "conversationId" to message.conversationId,
            "parentMessageId" to message.parentMessageId,
            "replyCount" to message.replyCount,
            "mentionedUsers" to message.mentionedUsers.map { getUserMap(it) }.toList(),
            "hasMentionedMe" to message.hasMentionedMe(),
            "reactions" to message.reactions.map { getReactionCount(it) }.toList(),
            "unreadRepliesCount" to message.unreadRepliesCount,
            "methodName" to methodName,
            "quotedMessageId" to message.quotedMessageId,
            "quotedMessage" to getMessageMap(message.quotedMessage)
        )
        when (message) {
            is TextMessage ->map.putAll(
                hashMapOf(
                    "text" to message.text,
                    "tags" to message.tags,
                    "moderationStatus" to getModerationStatusValue(message.moderationStatus),
                )
            )
            is MediaMessage -> map.putAll(
                hashMapOf(
                    "caption" to message.caption,
                    "attachment" to getAttachmentMap(message.attachment),
                    "tags" to message.tags,
                    "moderationStatus" to getModerationStatusValue(message.moderationStatus),
                    "attachments" to message.attachments?.map { getAttachmentMap(it) }?.toList(),
                    "files" to message.files?.map { it.absolutePath }?.toList(),
                    )
            )
            is CustomMessage -> map.putAll(
                hashMapOf(
                    "subType" to message.subType,
                    "customData" to  message.customData?.toString(),
                    "tags" to message.tags,
                    "text" to message.conversationText,
                    "updateConversation" to message.willUpdateConversation(),
                    "sendNotification" to message.willSendNotification()
                )
            )
            is Action -> map.putAll(
                hashMapOf(
                    "message" to message.message,
                    "rawData" to message.rawData,
                    "action" to message.action,
                    "oldScope" to message.oldScope,
                    "newScope" to message.newScope,
                    "actionOn" to when (message.actionOn) {
                        null -> null
                        is User -> getUserMap(message.actionOn as User)
                        is Group -> getGroupMap(message.actionOn as Group)
                        is BaseMessage -> getMessageMap(message.actionOn as BaseMessage)
                        else -> null
                    },
                    "actionFor" to when (message.actionFor) {
                        null -> null
                        is User -> getUserMap(message.actionFor as User)
                        is Group -> getGroupMap(message.actionFor as Group)
                        is BaseMessage -> getMessageMap(message.actionFor as BaseMessage)
                        else -> null
                    },
                    "actionBy" to when (message.actionBy) {
                        null -> null
                        is User -> getUserMap(message.actionBy as User)
                        is Group -> getGroupMap(message.actionBy as Group)
                        is BaseMessage -> getMessageMap(message.actionBy as BaseMessage)
                        else -> null
                    }

                )
            )

            is Call-> map.putAll(
                hashMapOf(
                    "sessionId" to message.sessionId,
                    "callStatus" to message.callStatus,
                    "action" to message.action,
                    "rawData" to message.rawData,
                    "initiatedAt" to message.initiatedAt,
                    "joinedAt" to message.joinedAt,
                    "callInitiator" to when (message.callInitiator) {
                        is User -> getUserMap(message.callInitiator as User)
                        is Group -> getGroupMap(message.callInitiator as Group)
                        else -> null
                    },
                    "callReceiver" to when (message.callReceiver) {
                        is User -> getUserMap(message.callReceiver as User)
                        is Group -> getGroupMap(message.callReceiver as Group)
                        else -> null
                    }
                )
            )

            is InteractiveMessage -> map.putAll(
                linkedMapOf(
                    "interactionGoal" to when (message.interactionGoal) {
                        null -> null
                        else -> getInteractionGoalMap(message.interactionGoal)
                    },
                    "interactiveData" to  message.interactiveData?.toString(),
                    "tags" to message.tags,
                    "allowSenderInteraction" to message.isAllowSenderInteraction,

                    "interactions" to message.interactions?.map { e -> getInteractionMap(e) }

            ))
            is AIAssistantMessage -> map.putAll(
                linkedMapOf(
                    "runId" to message.runId,
                    "threadId" to message.threadId,
                    "text" to message.text,
                    "tags" to message.tags,
                ))
            is AIToolResultMessage -> map.putAll(
                linkedMapOf(
                    "runId" to message.runId,
                    "threadId" to message.threadId,
                    "text" to message.text,
                    "toolCallId" to message.toolCallId,
                    "tags" to message.tags,
                ))
            is AIToolArgumentMessage -> map.putAll(
                linkedMapOf(
                    "runId" to message.runId,
                    "threadId" to message.threadId,
                    "toolCalls" to message.toolCalls?.map { toolCall ->
                        mapOf(
                            "id" to toolCall.id,
                            "type" to toolCall.type,
                            "displayName" to toolCall.displayName,
                            "executionText" to toolCall.executionText,
                            "function" to mapOf(
                                "name" to toolCall.function?.name,
                                "arguments" to toolCall.function?.arguments
                            )
                        )
                    },
                    "tags" to message.tags,
                )
            )

        }
        return map
    }

    private fun getMapFromJsonObject(jsonObj: JSONObject?): HashMap<String, Any?>?{
        if(jsonObj==null)return null;
        val data:HashMap<String, Any?>  = HashMap()
        for( keys in jsonObj.keys()){
            if(jsonObj.get(keys) is JSONObject){
                data[keys] = getMapFromJsonObject(jsonObj.get(keys) as JSONObject)
            }else if(jsonObj.get(keys) is JSONArray){
                data[keys] = {}
            }
            else{
                data[keys] = jsonObj.get(keys)
            }
        }
        return data
    }

    private fun getTypingIndicatorMap(typingIndicator: TypingIndicator? , methodName : String = ""): HashMap<String, Any?>? {
        if (typingIndicator == null) return null
        val map: HashMap<String, Any?> = hashMapOf(
            "receiverId" to typingIndicator.receiverId,
            "receiverType" to typingIndicator.receiverType,
            "metadata" to typingIndicator.metadata,
            //"sender" to getUserMap(typingIndicator.sender),
            "sender" to when (typingIndicator.sender) {
                is User -> getUserMap(typingIndicator.sender as User)
                is Group -> getGroupMap(typingIndicator.sender as Group)
                else -> null
            },
            "methodName" to methodName
        )
        return map
    }

    private fun getTransientMessageMap(transientMessage: TransientMessage? , methodName : String = ""): HashMap<String, Any?>? {
        if (transientMessage == null) return null
        var data:HashMap<String, Any?>  = HashMap() ;
        for( keys in transientMessage.data.keys()){
            data[keys] = transientMessage.data.get(keys)
        }
        val map: HashMap<String, Any?> = hashMapOf(
            "receiverId" to transientMessage.receiverId,
            "receiverType" to transientMessage.receiverType,
            //"sender" to getUserMap(typingIndicator.sender),
            "sender" to when (transientMessage.sender) {
                is User -> getUserMap(transientMessage.sender as User)
                is Group -> getGroupMap(transientMessage.sender as Group)
                else -> null
            },
            "methodName" to methodName,
            "data" to data
        )
        return map
    }

    private fun getAttachmentMap(attachment: Attachment?): HashMap<String, Any?>? {
        if (attachment == null) return null
        return hashMapOf(
            "className" to "Attachment",
            "fileName" to attachment.fileName,
            "fileExtension" to attachment.fileExtension,
            "fileSize" to attachment.fileSize,
            "fileMimeType" to attachment.fileMimeType,
            "fileUrl" to attachment.fileUrl
        )
    }

    private fun getConversationMap(conversation: Conversation, methodName : String = ""): HashMap<String, Any?> {
        return hashMapOf(
            "conversationId" to conversation.conversationId,
            "conversationType" to conversation.conversationType,
            "conversationWith" to when (conversation.conversationWith) {
                is User -> getUserMap(conversation.conversationWith as User)
                is Group -> getGroupMap(conversation.conversationWith as Group)
                else -> null
            },
            "lastMessage" to getMessageMap(conversation.lastMessage),
            "unreadMessageCount" to conversation.unreadMessageCount,
            "updatedAt" to conversation.updatedAt,
            "tags" to conversation.tags,
            "unreadMentionsCount" to conversation.unreadMentionsCount,
            "lastReadMessageId" to conversation.lastReadMessageId,
            "latestMessageId" to conversation.latestMessageId,
            "methodName" to methodName

        )
    }

    private fun getGroupMap(group: Group ,methodName : String = ""): HashMap<String, Any?> {
        val groupMap = group.toMap()
        return hashMapOf(
            "guid" to group.guid,
            "name" to group.name,
            "type" to groupMap["type"],
            "password" to group.password,
            "icon" to group.icon,
            "description" to group.description,
            "owner" to group.owner,
            "metadata" to group.metadata?.toString(),
            "createdAt" to group.createdAt,
            "updatedAt" to group.updatedAt,
            "hasJoined" to (groupMap["hasJoined"]?.toInt() == 1),
            "joinedAt" to group.joinedAt,
            "scope" to group.scope,
            "membersCount" to group.membersCount,
            "tags" to group.tags,
            "isBannedFromGroup" to group.isBannedFromGroup,
            "methodName" to methodName
        )
    }

    private fun getUserMap(user: User, methodName: String = ""): HashMap<String, Any?> {
        return hashMapOf(
            "uid" to user.uid,
            "name" to user.name,
            "avatar" to user.avatar,
            "link" to user.link,
            "role" to user.role,
            "metadata" to user.metadata?.toString(),
            "status" to user.status,
            "statusMessage" to user.statusMessage,
            "lastActiveAt" to user.lastActiveAt,
            "tags" to user.tags,
            "blockedByMe" to user.isBlockedByMe,
            "hasBlockedMe" to user.isHasBlockedMe,
            "methodName" to methodName
        )
    }

    private fun getReactionCount(reactionCount: ReactionCount, methodName: String = ""): HashMap<String, Any?> {
        return hashMapOf(
            "count" to reactionCount.count,
            "reaction" to reactionCount.reaction,
            "reactedByMe" to reactionCount.reactedByMe,
            "methodName" to methodName
        )
    }

    private fun getGroupMemberMap(groupMember: GroupMember,methodName : String = ""): HashMap<String, Any?> {
        val map: HashMap<String, Any?> = getUserMap(groupMember)
        map.putAll(
            hashMapOf(
                "scope" to groupMember.scope,
                "joinedAt" to groupMember.joinedAt,
                "methodName" to methodName
            )
        )
        return map
    }

    private fun getMessageReceiptMap(messageReceipt:  MessageReceipt?,methodName : String = ""): HashMap<String, Any?>? {
        if (messageReceipt == null) return null
        return  hashMapOf(
            "messageId" to messageReceipt.messageId,
            "sender" to  getUserMap(messageReceipt.sender),
            "receivertype" to messageReceipt.receivertype,
            "receiverId" to messageReceipt.receiverId,
            "timestamp" to messageReceipt.timestamp,
            "receiptType" to messageReceipt.receiptType,
            "deliveredAt" to messageReceipt.deliveredAt,
            "readAt" to messageReceipt.readAt,
            "messageSender" to messageReceipt.messageSender,
            "methodName" to methodName
        );
    }

    private fun getCometChatExceptionMap(exception: CometChatException,methodName : String = ""): HashMap<String, Any?> {
        return hashMapOf(
            "code" to exception.code,
            "details" to exception.details,
            "message" to exception.message,
            "methodName" to methodName
        )
    }

    private fun getInteractionGoalMap(interactionGoal: InteractionGoal): HashMap<String, Any?>? {
        return hashMapOf(
            "elementIds" to when (interactionGoal.elementIds) {
                null -> listOf<String>()
                else -> interactionGoal.elementIds
            },
            "type" to when (interactionGoal.type) {
                null -> "none"
                else -> interactionGoal.type
            },
        )
    }

    private fun getInteractionReceiptMap(receipt: InteractionReceipt, methodName : String = ""): HashMap<String, Any?>? {
        return hashMapOf(
            "sender" to when (receipt.sender) {
                is User -> getUserMap(receipt.sender as User)
                is Group -> getGroupMap(receipt.sender as Group)
                else -> null
            },
            "interactions" to receipt.interactions?.map { e -> getInteractionMap(e) },
            "receiverId" to receipt.receiverId,
            "messageId" to receipt.messageId,
            "receiverType" to receipt.receiverType,
            "methodName" to methodName
        )
    }

    private fun getInteractionMap(interaction: Interaction): HashMap<String, Any?>? {
        return hashMapOf(
            "elementId" to interaction.elementId,
            "interactedAt" to interaction.interactedAt,
        )
    }

    private fun sendMediaMessage(call: MethodCall, result: Result) {
        val receiverID: String = call.argument("receiverId") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val messageType: String = call.argument("messageType") ?: ""
        val filePath: String = call.argument("filePath") ?: ""
        val caption: String = call.argument("caption") ?: ""
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val hasAttachment: Boolean = call.argument("hasAttachment") ?: false
        val attachmentFileName: String = call.argument("attachmentFileName") ?: ""
        val attchemntFileExtension: String = call.argument("attchemntFileExtension") ?: ""
        val attachmentFileUrl: String = call.argument("attachmentFileUrl") ?: ""
        val attachmentMimeType: String = call.argument("attachmentMimeType") ?: ""
        val metadata: String = call.argument("metadata") ?: ""
        val muid: String = call.argument("muid") ?: ""
        val attachments: List<HashMap<String,Any?>> = call.argument("attachments")?: emptyList()
        val files: List<String> = call.argument("files") ?: emptyList()

        val attachmentList: MutableList<Attachment>  = ArrayList()
        for (item in attachments){
            attachmentList.add(toAttachment(item))
        }
        val quotedMessageId: Long = call.getLongArg("quotedMessageId")


        var mediaMessage: MediaMessage;

        if (filePath.isNotEmpty()) {
            mediaMessage = MediaMessage(receiverID, File(filePath), messageType, receiverType)
        } else {
            mediaMessage = MediaMessage(receiverID, messageType, receiverType)
        }

        // ✅ Set attachments if any
        if (hasAttachment) {
            val allAttachments: MutableList<Attachment> = mutableListOf()

            val attachment = Attachment().apply {
                fileName = attachmentFileName
                fileExtension = attchemntFileExtension
                fileUrl = attachmentFileUrl
                fileMimeType = attachmentMimeType
            }

            allAttachments.add(attachment)
            if (attachmentList.isNotEmpty()) {
                allAttachments.addAll(attachmentList)
            }

            mediaMessage.attachments = allAttachments
        }

        // ✅ Set multiple files
        if (files.isNotEmpty()) {
            mediaMessage.files = files.map { File(it) }
        }

        if(muid!=null&& !muid.isEmpty() ){
            mediaMessage.muid = muid;
        }

        if (caption.isNotEmpty()) mediaMessage.caption = caption

        if (parentMessageId > 0) mediaMessage.parentMessageId = parentMessageId

        if(tags.isNotEmpty()) mediaMessage.tags = tags

        if(metadata.isNotEmpty()){
            mediaMessage.metadata = JSONObject(metadata)
        }

        if (quotedMessageId > 0) mediaMessage.quotedMessageId = quotedMessageId


        CometChat.sendMediaMessage(
            mediaMessage,
            object : CallbackListener<MediaMessage>() {
                override fun onSuccess(message: MediaMessage) {
                    Log.d("sendMediaMessage", "Media message sent successfully: $message")
                    result.success(getMessageMap(message))
                }

                override fun onError(e: CometChatException) {
                    Log.e("sendMediaMessage", "Message sending failed with exception: " + e.message)
                    result.error(e.code!!, e.message, e.details)
                }
            })
    }

    private fun sendCustomMessage(call: MethodCall, result: Result) {
        val receiverId: String = call.argument("receiverId") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val customType: String = call.argument("customType") ?: ""
        val customDataPassed: Map<String,String> = call.argument("customData") ?: mapOf()
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val muid: String = call.argument("muid") ?: ""
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val metadata: String = call.argument("metadata") ?: ""
        val text: String? = call.argument("text")
        val updateConversation: Boolean = call.argument("updateConversation") ?: false
        val sendNotification: Boolean = call.argument("sendNotification") ?: false
        val quotedMessageId: Long = call.getLongArg("quotedMessageId")

        val customData=JSONObject()
        for ((k, v) in customDataPassed) {
            customData.put(k,v)
        }
        val customMessage = CustomMessage(receiverId, receiverType,customType, customData)

        if(muid.isNotEmpty()) customMessage.muid  = muid

        if(tags.isNotEmpty()) customMessage.tags = tags

        if (parentMessageId > 0) customMessage.parentMessageId = parentMessageId

        if(metadata.isNotEmpty()){
            customMessage.metadata = JSONObject(metadata)
        }

        if(text != null) customMessage.conversationText = text

        if(updateConversation) customMessage.shouldUpdateConversation(true)

        if(sendNotification) customMessage.shouldSendNotification(true)

        if (quotedMessageId > 0) customMessage.quotedMessageId = quotedMessageId


        CometChat.sendCustomMessage(customMessage, object : CallbackListener<CustomMessage>() {
            override fun onSuccess(customMessage: CustomMessage) {
                Log.d("TAG", customMessage.toString())
                result.success(getMessageMap(customMessage))
            }
            override fun onError(e: CometChatException) {
                Log.d("TAG", e.message.toString())
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun addMessageListener() {
        CometChat.addMessageListener(
            "cometchat.message",
            object : CometChat.MessageListener() {
                override fun onTextMessageReceived(message: TextMessage) {
                    Log.d("receiveMessage", "Message received successfully: ${message.text} sender: ${message.sender?.uid} receiver: ${message.receiverUid}")
                    messageStreamSink?.success(getMessageMap(message,"onTextMessageReceived"))
                }
                override fun onMediaMessageReceived(message: MediaMessage) {
                    message.caption
                    Log.d("receiveMessage", "Message received successfully: ${message.attachment.fileUrl} sender: ${message.sender?.uid} receiver: ${message.receiverUid}")
                    messageStreamSink?.success(getMessageMap(message,"onMediaMessageReceived"))
                }
                override fun onMessageDeleted(message: BaseMessage) {
                    Log.d("deleteMessage", "Message deleted successfully")
                    messageStreamSink?.success(getMessageMap(message,"onMessageDeleted"))
                }
                override fun onMessageEdited(message: BaseMessage?) {
                    Log.d("TAG", "Message Edited")
                    messageStreamSink?.success(getMessageMap(message,"onMessageEdited"))
                }
                override fun onTransientMessageReceived(transientMessage: TransientMessage?) {
                    Log.d("TAG", "Transient Message Receaved")
                    messageStreamSink?.success(getTransientMessageMap(transientMessage,"onTransientMessageReceived"))
                }
                override fun onTypingStarted(typingMessage: TypingIndicator?) {
                    Log.d("TAG", "Typing Started Native")
                    messageStreamSink?.success(getTypingIndicatorMap(typingMessage, "onTypingStarted"))
                }
                override fun onTypingEnded(typingMessage: TypingIndicator?) {
                    Log.d("TAG", "Typing Ended Native")
                    messageStreamSink?.success(getTypingIndicatorMap(typingMessage,"onTypingEnded"))
                }
                override fun onMessagesRead(messageReceipt: MessageReceipt?) {
                    Log.d("TAG", "onMessagesRead Native")
                    messageStreamSink?.success(getMessageReceiptMap(messageReceipt,"onMessagesRead"))
                }
                override fun onMessagesDelivered(messageReceipt: MessageReceipt?) {
                    Log.d("TAG", "onMessagesDelivered Native")
                    messageStreamSink?.success(getMessageReceiptMap(messageReceipt,"onMessagesDelivered"))
                }
                override fun onMessagesReadByAll(messageReceipt: MessageReceipt?) {
                    messageStreamSink?.success(getMessageReceiptMap(messageReceipt,"onMessagesReadByAll"))
                }
                override fun onMessagesDeliveredToAll(messageReceipt: MessageReceipt?) {
                    messageStreamSink?.success(getMessageReceiptMap(messageReceipt,"onMessagesDeliveredToAll"))
                }
                override fun onCustomMessageReceived(customMessage: CustomMessage?) {
                    Log.d("TAG", "onCustomMessageReceived Native")
                    messageStreamSink?.success(getMessageMap(customMessage,"onCustomMessageReceived"))
                }
                override fun onInteractiveMessageReceived(interactiveMessage: InteractiveMessage?) {
                    Log.d("TAG", "onInteractiveMessageReceived Native")
                    messageStreamSink?.success(getMessageMap(       interactiveMessage,"onInteractiveMessageReceived"))
                }
                override fun onInteractionGoalCompleted(interactionReceipt: InteractionReceipt) {
                    Log.d("TAG", "onInteractionGoalCompleted Native")
                    messageStreamSink?.success(getInteractionReceiptMap(interactionReceipt, "onInteractionGoalCompleted"))
                }

                override fun onMessageReactionAdded(reactionEvent: ReactionEvent) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["reactionEvent"] = getReactionEventMap(reactionEvent)
                    responseMap["methodName"] = "onMessageReactionAdded"
                    messageStreamSink?.success(responseMap)
                }
                override fun onMessageReactionRemoved(reactionEvent: ReactionEvent) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["reactionEvent"] = getReactionEventMap(reactionEvent)
                    responseMap["methodName"] = "onMessageReactionRemoved"
                    messageStreamSink?.success(responseMap)
                }
                override fun onMessageModerated(message: BaseMessage) {
                    messageStreamSink?.success(getMessageMap(message,"onMessageModerated"))
                }

                override fun onAIAssistantMessageReceived(message: AIAssistantMessage?) {
                    messageStreamSink?.success(getMessageMap(message,"onAIAssistantMessageReceived"))
                }

                override fun onAIToolResultReceived(message: AIToolResultMessage?) {
                    messageStreamSink?.success(getMessageMap(message,"onAIToolResultReceived"))
                }

                override fun onAIToolArgumentsReceived(message: AIToolArgumentMessage?) {
                    messageStreamSink?.success(getMessageMap(message,"onAIToolArgumentsReceived"))
                }
            })
    }

    private fun addAIAssistantListener() {
        CometChat.addAIAssistantListener(
            "cometchat.stream",
            object : CometChat.AIAssistantListener() {
                override fun onAIAssistantEventReceived(aiAssistantBaseEvent: AIAssistantBaseEvent) {
                    val responseMap = hashMapOf<String, Any?>()
                    responseMap["event"] = getAIAssistantEventMap(aiAssistantBaseEvent)
                    responseMap["methodName"] = "onAIAssistantEventReceived"
                        messageStreamSink?.success(responseMap)
                }
            }
        )
    }

    private fun getAIAssistantEventMap(event: AIAssistantBaseEvent): HashMap<String, Any?> {
        val map = HashMap<String, Any?>()
        val data = HashMap<String, Any?>()

        // Common base fields
        map["id"] = event.id
        map["type"] = event.type
        map["conversationId"] = event.conversationId
        map["parentId"] = event.parentId
        map["additionalProperties"] = event.additionalProperties.toString()

        // Event-specific fields go into "data"
        when (event) {
            is AIAssistantToolResultEvent -> {
                data["streamMessageId"] = event.streamMessageId
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["toolCallId"] = event.toolCallId
                data["content"] = event.content
                data["role"] = event.role
                data["toolCallName"] = event.toolCallName
                data["displayName"] = event.displayName
                data["executionText"] = event.executionText
                data["arguments"] = event.arguments
            }
            is AIAssistantRunStartedEvent -> {
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["streamMessageId"] = event.streamMessageId
                data["role"] = event.role
            }
            is AIAssistantToolEndedEvent -> {
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["toolCallId"] = event.toolCallId
                data["toolCallName"] = event.toolCallName
                data["displayName"] = event.displayName
                data["executionText"] = event.executionText
                data["arguments"] = event.arguments
            }
            is AIAssistantToolStartedEvent -> {
                data["streamParentMessageId"] = event.streamParentMessageId
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["toolCallId"] = event.toolCallId
                data["toolCallName"] = event.toolCallName
                data["displayName"] = event.displayName
                data["executionText"] = event.executionText
                data["arguments"] = event.arguments
            }
            is AIAssistantMessageEndedEvent -> {
                data["type"] = event.type
                data["messageId"] = event.messageId
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["streamMessageId"] = event.streamMessageId
            }
            is AIAssistantRunFinishedEvent -> {
                data["runId"] = event.runId
                data["threadId"] = event.threadId
            }
            is AIAssistantToolArgumentEvent -> {
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["toolCallId"] = event.toolCallId
                data["delta"] = event.delta
                data["toolCallName"] = event.toolCallName
                data["displayName"] = event.displayName
                data["executionText"] = event.executionText
                data["arguments"] = event.arguments
            }
            is AIAssistantContentReceivedEvent -> {
                data["streamMessageId"] = event.streamMessageId
                data["runId"] = event.runId
                data["threadId"] = event.threadId
                data["delta"] = event.delta
            }
        }

        // Attach data map if not empty
        if (data.isNotEmpty()) {
            map["data"] = data
        }

        return map
    }



    private fun addUserListener(){
        CometChat.addUserListener(
            "cometchat.user",
            object : CometChat.UserListener() {
                override fun onUserOnline(user: User?) {
                    Log.d("TAG", "onUserOnline Native ${user?.status}")
                    if(user!=null) messageStreamSink?.success(getUserMap(user,"onUserOnline"))
                }
                override fun onUserOffline(user: User?) {
                    Log.d("TAG", "onUserOffline Native ${user?.status}")
                    if(user !=null) messageStreamSink?.success(getUserMap(user,"onUserOffline"))
                }
            }
        )
    }

    private fun addGroupListener(){
        CometChat.addGroupListener(
            "cometchat.group",
            object : CometChat.GroupListener() {
                override fun onGroupMemberJoined(action: Action?, user: User?, group: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(user!=null) responseMap["joinedUser"]  = getUserMap(user)
                    if(group!=null) responseMap["joinedGroup"] = getGroupMap(group)
                    responseMap["methodName"] = "onGroupMemberJoined"
                    messageStreamSink?.success(responseMap)
                }

                override fun onGroupMemberLeft(action: Action?, user: User?, group: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(user!=null) responseMap["leftUser"]  = getUserMap(user)
                    if(group!=null) responseMap["leftGroup"] = getGroupMap(group)
                    responseMap["methodName"] = "onGroupMemberLeft"
                    messageStreamSink?.success(responseMap)
                }

                override fun onGroupMemberKicked(action: Action?, kickedUser: User?, kickedBy: User?, kickedFrom: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(kickedUser!=null) responseMap["kickedUser"]  = getUserMap(kickedUser)
                    if(kickedBy!=null) responseMap["kickedBy"]  = getUserMap(kickedBy)
                    if(kickedFrom!=null) responseMap["kickedFrom"] = getGroupMap(kickedFrom)
                    responseMap["methodName"] = "onGroupMemberKicked"
                    messageStreamSink?.success(responseMap)
                }

                override fun onGroupMemberBanned(action: Action?, bannedUser: User?, bannedBy: User?, bannedFrom: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(bannedUser!=null) responseMap["bannedUser"]  = getUserMap(bannedUser)
                    if(bannedBy!=null) responseMap["bannedBy"]  = getUserMap(bannedBy)
                    if(bannedFrom!=null) responseMap["bannedFrom"] = getGroupMap(bannedFrom)
                    responseMap["methodName"] = "onGroupMemberBanned"
                    messageStreamSink?.success(responseMap)
                }

                override fun onGroupMemberUnbanned(action: Action?, unbannedUser: User?, unbannedBy: User?, unbannedFrom: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(unbannedUser!=null) responseMap["unbannedUser"]  = getUserMap(unbannedUser)
                    if(unbannedBy!=null) responseMap["unbannedBy"]  = getUserMap(unbannedBy)
                    if(unbannedFrom!=null) responseMap["unbannedFrom"] = getGroupMap(unbannedFrom)
                    responseMap["methodName"] = "onGroupMemberUnbanned"
                    messageStreamSink?.success(responseMap)
                }

                override fun onGroupMemberScopeChanged(
                    action: Action?,
                    updatedBy: User?,
                    updatedUser: User?,
                    scopeChangedTo: String?,
                    scopeChangedFrom: String?,
                    group: Group?
                ) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(updatedBy!=null) responseMap["updatedBy"]  = getUserMap(updatedBy)
                    if(updatedUser!=null) responseMap["updatedUser"]  = getUserMap(updatedUser)
                    responseMap["scopeChangedTo"] = scopeChangedTo
                    responseMap["scopeChangedFrom"] = scopeChangedFrom
                    if(group!=null) responseMap["group"] = getGroupMap(group)
                    responseMap["methodName"] = "onGroupMemberScopeChanged"
                    messageStreamSink?.success(responseMap)
                }

                override fun onMemberAddedToGroup(action: Action?, addedby: User?, userAdded: User?, addedTo: Group?) {
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["action"] = getMessageMap(action)
                    if(addedby!=null) responseMap["addedby"]  = getUserMap(addedby)
                    if(userAdded!=null) responseMap["userAdded"]  = getUserMap(userAdded)
                    if(addedTo!=null) responseMap["addedTo"] = getGroupMap(addedTo)
                    responseMap["methodName"] = "onMemberAddedToGroup"
                    messageStreamSink?.success(responseMap)
                }
            })
    }


    private fun addLoginListener(){
        CometChat.addLoginListener(
            "cometchat.login",
            object : CometChat.LoginListener() {
                override fun loginSuccess(user: User?) {
                    Log.d("TAG", "loginSuccess Native")
                    if(user!=null) messageStreamSink?.success(getUserMap(user,"loginSuccess"))
                }

                override fun loginFailure(exception: CometChatException?) {
                    Log.d("TAG", "loginFailure Native")
                    if(exception!=null)messageStreamSink?.success(getCometChatExceptionMap(exception,"loginFailure"))
                }

                override fun logoutSuccess() {
                    Log.d("TAG", "logoutSuccess Native")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "logoutSuccess"
                    messageStreamSink?.success(responseMap)
                }

                override fun logoutFailure(exception: CometChatException?) {
                    Log.d("TAG", "logoutFailure Native")
                    if(exception!=null)messageStreamSink?.success(getCometChatExceptionMap(exception,"logoutFailure"))
                }
            })
    }


    private fun addConnectionListener(){
        CometChat.addConnectionListener(
            "cometchat.connection",
            object : CometChat.ConnectionListener {
                override fun onConnected() {
                    Log.i(TAG, "WS: onConnected")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "onConnected"
                    messageStreamSink?.success(responseMap)
                }

                override fun onConnecting() {
                    Log.i(TAG, "WS: onConnecting")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "onConnecting"
                    messageStreamSink?.success(responseMap)
                }

                override fun onDisconnected() {
                    Log.i(TAG, "WS: onDisconnected")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "onDisconnected"
                    messageStreamSink?.success(responseMap)
                }

                override fun onFeatureThrottled() {
                    Log.i(TAG, "WS: onFeatureThrottled")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "onFeatureThrottled"
                    messageStreamSink?.success(responseMap)
                }

                override fun onConnectionError(error: CometChatException) {
                    Log.i(TAG, "WS: onConnectionError")
                    val responseMap :HashMap<String,Any?> = HashMap()
                    responseMap["methodName"] = "onConnectionError"
                    responseMap["error"] = errorToMap(error)
                    messageStreamSink?.success(responseMap)
                }
            })
    }

    private fun fetchPreviousMessages(call: MethodCall, result: Result) {
        val limit: Int = call.argument("limit") ?: -1
        val uid: String = call.argument("uid") ?: ""
        val guid: String = call.argument("guid") ?: ""
        val searchTerm: String = call.argument("searchTerm") ?: ""
        val messageId: Long = call.getLongArg("messageId")
        val timestamp: Long = (call.argument("timestamp") ?: 0).toLong()
        val unread: Boolean = call.argument("unread") ?: false
        val hideblockedUsers: Boolean = call.argument("hideblockedUsers") ?: false
        val updateAfter: Long = (call.argument("updateAfter")  ?: 0).toLong()
        val updatesOnly: Boolean = call.argument("updatesOnly") ?: false
        val categories: List<String> = call.argument("categories")?: emptyList()
        val types: List<String> = call.argument("types") ?: emptyList()
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val hideReplies: Boolean = call.argument("hideReplies") ?: false
        val hideDeletedMessages: Boolean = call.argument("hideDeletedMessages") ?: false
        val withTags: Boolean = call.argument("withTags") ?: false
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val interactionGoalCompletedOnly: Boolean = call.argument("interactionGoalCompletedOnly") ?: false
        var key: String? = call.argument("key")
        var hasReactions: Boolean = call.argument("hasReactions") ?: false
        var hasAttachments: Boolean = call.argument("hasAttachments") ?: false
        var mentionedUids: List<String> = call.argument("mentionedUids")?: emptyList()
        var hasMentions: Boolean = call.argument("hasMentions") ?: false
        var hasLinks: Boolean = call.argument("hasLinks") ?: false

        val mentionsWithTagInfo : Boolean = call.argument("mentionsWithTagInfo") ?: false
        val mentionsWithBlockedInfo: Boolean = call.argument("mentionsWithBlockedInfo") ?: false
        var attachmentTypesString: List<String> = call.argument("attachmentTypes")?: emptyList()
        var withParent: Boolean = call.argument("withParent") ?: false
        var hideQuotedMessages: Boolean = call.argument("hideQuotedMessages") ?: false

        val attachmentTypes = attachmentTypesString.mapNotNull { typeStr ->
            val type = AttachmentType.get(typeStr)
            if (type == null) {
                Log.w("AttachmentType", "Unknown attachment type received from Flutter: $typeStr")
                null
            } else {
                type
            }
        }


        lateinit var  messagesRequest: MessagesRequest

        if( key==null || !messageRequestMap.contains(key) || ((messageRequestMap.get(key))==null) ){
            var builder: MessagesRequest.MessagesRequestBuilder = MessagesRequest.MessagesRequestBuilder()

            if (limit > 0) builder = builder.setLimit(limit)

            if (uid.isNotEmpty()) {
                builder = builder.setUID(uid)
            } else if (guid.isNotEmpty()) {
                builder = builder.setGUID(guid)
            }

            if (searchTerm.isNotEmpty()) builder = builder.setSearchKeyword(searchTerm)

            if (messageId > 0) builder = builder.setMessageId(messageId)

            if (timestamp > 0) builder = builder.setTimestamp(timestamp)

            if (unread) {
                builder = builder.setUnread(unread)
            }

            if (hideblockedUsers) builder = builder.hideMessagesFromBlockedUsers(hideblockedUsers)

            if (updateAfter>0) builder = builder.setUpdatedAfter(updateAfter)

            if (updatesOnly) builder = builder.updatesOnly(updatesOnly)

            if (categories.isNotEmpty()) builder = builder.setCategories(categories)

            if (types.isNotEmpty()) builder = builder.setTypes(types)

            if (parentMessageId > 0) builder = builder.setParentMessageId(parentMessageId)

            if (hideReplies) builder = builder.hideReplies(hideReplies)

            if (hideDeletedMessages) builder = builder.hideDeletedMessages(hideDeletedMessages)

            if(withTags) builder  = builder.withTags(withTags)

            if(tags.isNotEmpty()) builder = builder.setTags(tags)

            if(hasAttachments) builder = builder.hasAttachments(hasAttachments)

            if(hasLinks) builder = builder.hasLinks(hasLinks)

            if(hasReactions) builder = builder.hasReactions(hasReactions)

            if(hasMentions) builder = builder.hasMentions(hasMentions)

            if(mentionedUids.isNotEmpty()) builder = builder.setMentionedUIDs(mentionedUids)

            if(attachmentTypes.isNotEmpty()) builder = builder.setAttachmentTypes(attachmentTypes)

            if(withParent) builder = builder.withParent(withParent)

            if(hideQuotedMessages) builder = builder.hideQuotedMessages(hideQuotedMessages)

            builder = builder.mentionsWithTagInfo(mentionsWithTagInfo).mentionsWithBlockedInfo(mentionsWithBlockedInfo)
            if (interactionGoalCompletedOnly) builder = builder.setInteractionGoalCompletedOnly(interactionGoalCompletedOnly)

            messagesRequest= builder.build()

            if(key==null){
                counter++
                key = counter.toString()

            }

            messageRequestMap[key] = messagesRequest
        }else{
            messagesRequest =   messageRequestMap[key]!!
        }

        messagesRequest.fetchPrevious(object : CallbackListener<List<BaseMessage>>() {
            override fun onSuccess(messages: List<BaseMessage>) {
                val list = messages.map { e -> getMessageMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }
            override fun onError(e: CometChatException) {
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun fetchNextConversations(call: MethodCall, result: Result) {
        val limit: Int = call.argument("limit") ?: -1
        val type: String? = call.argument("type")
        val init: Boolean = call.argument("init") ?: true
        val withUserAndGroupTags: Boolean = call.argument("withUserAndGroupTags") ?: false
        val withTags: Boolean = call.argument("withTags") ?: false
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val includeBlockedUsers: Boolean = call.argument("includeBlockedUsers") ?: false
        val withBlockedInfo: Boolean = call.argument("withBlockedInfo") ?: false
        val unread: Boolean = call.argument("unread") ?: false
        var key: String? = call.argument("key")
        var searchKeyword: String? = call.argument("searchKeyword")
        val userTags: List<String> = call.argument("userTags") ?: emptyList()
        val groupTags: List<String> = call.argument("groupTags") ?: emptyList()
        val setPage: Int = call.argument("setPage") ?: 0
        val hideAgentic: Boolean = call.argument("hideAgentic") ?: false
        val onlyAgentic: Boolean = call.argument("onlyAgentic") ?: false


        lateinit var  conversationRequest: ConversationsRequest

        if( key==null || !conversationRequestMap.contains(key) || ((conversationRequestMap.get(key))==null) ){
            var builder: ConversationsRequest.ConversationsRequestBuilder = ConversationsRequest.ConversationsRequestBuilder()

            if (limit > 0) builder = builder.setLimit(limit)

            if (type != null) builder = builder.setConversationType(type)

            if (searchKeyword != null) builder = builder.setSearchKeyword(searchKeyword)

            if(withUserAndGroupTags) builder = builder.withUserAndGroupTags(withUserAndGroupTags)

            if(withTags) builder  = builder.withTags(withTags)

            if(tags.isNotEmpty()) builder = builder.setTags(tags)

            if(includeBlockedUsers) builder = builder.includeBlockedUsers(includeBlockedUsers)

            if(withBlockedInfo) builder = builder.withBlockedInfo(withBlockedInfo)

            if(unread) builder = builder.setUnread(unread)

            if(userTags.isNotEmpty()) builder = builder.setUserTags(userTags)

            if(groupTags.isNotEmpty()) builder = builder.setGroupTags(groupTags)

            builder = builder.setPage(setPage)

            if(hideAgentic) builder = builder.hideAgentic(hideAgentic)

            if(onlyAgentic) builder = builder.onlyAgentic(onlyAgentic)

            conversationRequest = builder.build()

            if(key==null){
                counter++
                key = counter.toString()
            }

            conversationRequestMap[key] = conversationRequest
        }else{
            conversationRequest =   conversationRequestMap[key]!!
        }

        conversationRequest.fetchNext(object : CallbackListener<List<Conversation>>() {
            override fun onSuccess(conversations: List<Conversation>) {
                val list = conversations.map { e -> getConversationMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.e("fetchNextConversations", "Failed to fetch conversations: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun getConversation(call: MethodCall, result: Result) {
        val conversationWith: String = call.argument("conversationWith") ?: ""
        val conversationType: String = call.argument("conversationType") ?: ""
        CometChat.getConversation(conversationWith, conversationType, object: CallbackListener<Conversation>(){
            override fun onSuccess(conversation: Conversation) {
                result.success(getConversationMap(conversation))
            }

            override fun onError(e: CometChatException) {
                Log.e("getConversation", "Failed to fetch conversation: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun deleteMessage(call: MethodCall, result: Result) {
        val messageId: Long = call.getLongArg("messageId")
        CometChat.deleteMessage(messageId, object : CallbackListener<BaseMessage>() {
            override fun onSuccess(message: BaseMessage) {
                Log.d("deleteMessage", "deleteMessage onSuccess : " +"${message.id} ${message.type}" + message.category +" "+ message.deletedAt)
                result.success(getMessageMap(message));
            }

            override fun onError(e: CometChatException) {
                Log.d("deleteMessage", "deleteMessage onError : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun createGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val owner: String = call.argument("owner") ?: ""
        val name: String = call.argument("name") ?: ""
        val icon: String = call.argument("icon") ?: ""
        val description: String = call.argument("description") ?: ""
        val membersCount: Int = call.argument("membersCount")?: 0
        val createdAt: Long? = call.argument("createdAt")
        val joinedAt: Long? = call.argument("joinedAt")
        val updatedAt: Long? = call.argument("updatedAt")
        val tags: List<String>? = call.argument("tags")
        val type: String = call.argument("type") ?: ""
        val password: String = call.argument("password") ?: ""
        val scope: String = call.argument("scope") ?: ""
        val metadata: String? = call.argument("metadata")
        val group = Group()
        if(guid.isNotEmpty())group.guid = guid
        if(owner.isNotEmpty())group.owner = owner
        if(name.isNotEmpty())group.name = name
        if(icon.isNotEmpty())group.icon = icon
        if(description.isNotEmpty())group.description = description
        if(metadata!=null&& metadata.isNotEmpty()){
            group.metadata = JSONObject(metadata)
        }
        if(membersCount!=0) group.membersCount = membersCount
        if(createdAt!=null)group.createdAt = createdAt
        if(joinedAt!=null)group.joinedAt = joinedAt
        if(updatedAt!=null)group.updatedAt = updatedAt
        if(tags!=null) group.tags = tags
        if(type.isNotEmpty())group.groupType = type
        if(password.isNotEmpty())group.password = password
        if(scope.isNotEmpty())group.scope = scope

        CometChat.createGroup(group, object : CallbackListener<Group>() {
            override fun onSuccess(group: Group) {
                Log.d("createGroup", "Group created successfully: $group")
                result.success(getGroupMap(group))
            }

            override fun onError(e: CometChatException) {
                Log.d("createGroup", "Group creation failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun joinGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val groupType: String = call.argument("groupType") ?: ""
        val password: String = call.argument("password") ?: ""

        CometChat.joinGroup(
            guid,
            groupType,
            password,
            object : CallbackListener<Group>() {
                override fun onSuccess(group: Group) {
                    Log.d("joinGroup", "Group joined successfully: $group")
                    result.success(getGroupMap(group))
                }

                override fun onError(e: CometChatException) {
                    Log.d("joinGroup", "Group creation failed with exception: " + e.message)
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun leaveGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""

        CometChat.leaveGroup(guid, object : CallbackListener<String>() {
            override fun onSuccess(m: String) {
                Log.d("leaveGroup", "Group left successfully: $m")
                result.success(m)
            }

            override fun onError(e: CometChatException) {
                Log.d("leaveGroup", "Group leaving failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun deleteGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""

        CometChat.deleteGroup(guid, object : CallbackListener<String>() {
            override fun onSuccess(m: String) {
                Log.d("deleteGroup", "Group deleted successfully: $m")
                result.success(m)
            }

            override fun onError(e: CometChatException) {
                Log.d("deleteGroup", "Group delete failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun fetchNextGroupMembers(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val limit: Int = call.argument("limit") ?: -1
        val keyword: String = call.argument("keyword") ?: ""
        val init: Boolean = call.argument("init") ?: true
        val scopes: List<String> = call.argument("scopes")?: emptyList()
        var key: String? = call.argument("key")
        val setPage: Int = call.argument("setPage") ?: 0
        var status: String? = call.argument("status") ?: null

        lateinit var  groupMembersRequest : GroupMembersRequest

        if( key==null || !groupMemberRequestMap.contains(key) || ((groupMemberRequestMap.get(key))==null) ){
            var builder: GroupMembersRequest.GroupMembersRequestBuilder = GroupMembersRequest.GroupMembersRequestBuilder(guid)

            if (limit > 0) builder = builder.setLimit(limit)

            if (keyword.isNotEmpty()) builder = builder.setSearchKeyword(keyword)

            if (scopes.isNotEmpty()) builder = builder.setScopes(scopes)
            if (status!=null && status.isNotEmpty()) builder = builder.setStatus(status)

            builder = builder.setPage(setPage)

            groupMembersRequest = builder.build()
            if(key==null){
                counter++
                key = counter.toString()

            }

            groupMemberRequestMap[key] = groupMembersRequest
        }else{
            groupMembersRequest =   groupMemberRequestMap[key]!!
        }

        groupMembersRequest.fetchNext(object : CallbackListener<List<GroupMember>>() {
            override fun onSuccess(members: List<GroupMember>) {
                Log.d("fetchNextGroupMembers", "Group Member list fetched successfully: " + members.size)
                val list = members.map { e -> getGroupMemberMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("fetchNextGroupMembers", "Group Member list fetching failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun fetchNextGroups(call: MethodCall, result: Result) {
        val limit: Int = call.argument("limit") ?: -1
        val searchTerm: String = call.argument("searchTerm") ?: ""
        val init: Boolean = call.argument("init") ?: true
        val joinedOnly: Boolean = call.argument("joinedOnly") ?: false
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val withTags: Boolean = call.argument("withTags") ?: false
        val setPage: Int = call.argument("setPage") ?: 0

        var key: String? = call.argument("key")
        lateinit var  groupsRequest: GroupsRequest

        if( key==null || !groupRequestMap.contains(key) || ((groupRequestMap.get(key))==null) ){
            var builder: GroupsRequest.GroupsRequestBuilder = GroupsRequest.GroupsRequestBuilder()
            if (limit > 0) builder = builder.setLimit(limit)
            if (searchTerm.isNotEmpty()) builder.setSearchKeyWord(searchTerm)
            if (joinedOnly) builder = builder.joinedOnly(joinedOnly)
            if (tags.isNotEmpty()) builder = builder.setTags(tags)
            builder = builder.setPage(setPage)
            if (withTags) builder = builder.withTags(withTags)
            groupsRequest = builder.build()
            if(key==null){
                counter++
                key = counter.toString()
            }
            groupRequestMap[key] = groupsRequest
        }else {
            groupsRequest = groupRequestMap[key]!!
        }

        groupsRequest.fetchNext(object : CallbackListener<List<Group>>() {
            override fun onSuccess(groups: List<Group>) {
                Log.d("fetchNextGroups", "Groups list fetched successfully: " + groups.size)
                val list = groups.map { e -> getGroupMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("fetchNextGroups", "Groups list fetching failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun registerTokenForPushNotification(call: MethodCall, result: Result) {
        val token: String = call.argument("token") ?: ""
        CometChat.registerTokenForPushNotification(
            token,
            object : CallbackListener<String?>() {
                override fun onSuccess(s: String?) {
                    Log.e("onSuccessPN: ", s ?: "Done")
                    result.success(s)
                }

                override fun onError(e: CometChatException) {
                    Log.e("onErrorPN: ", "Token save failed: " + e.message)
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun getUnreadMessageCount(result: Result) {
        CometChat.getUnreadMessageCount(object :
            CallbackListener<HashMap<String, HashMap<String, Int>>>() {
            override fun onSuccess(counts: HashMap<String, HashMap<String, Int>>?) {
                Log.d("getUnreadMessageCount", "onSuccess: $counts")
                result.success(counts)
            }

            override fun onError(e: CometChatException) {
                Log.d("getUnreadMessageCount", "onError: ${e.message}")
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun markAsRead(call: MethodCall, result: Result) {
        val baseMessage: HashMap<String, Any?> = call.argument("baseMessage") ?: HashMap()
        var baseMessageObj:BaseMessage = toBaseMessage(baseMessage);

        CometChat.markAsRead(baseMessageObj, object : CallbackListener<Void?>() {
            override fun onSuccess(unused: Void?) {
                Log.d("markAsRead", "markAsRead : " + "success")
                result.success("Success")
            }

            override fun onError(e: CometChatException) {
                Log.e("error", "markAsRead : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun callExtension(call: MethodCall, result: Result) {
        val slug: String = call.argument("slug") ?: ""
        val requestType: String = call.argument("requestType") ?: ""
        var endPoint: String = call.argument("endPoint") ?: ""
        val body: JSONObject = JSONObject(call.argument("body") ?: emptyMap<String, Any>())

        if (endPoint.isNotEmpty() && !endPoint.startsWith("/")) {
            endPoint = "/$endPoint";
        }

        CometChat.callExtension(
            slug,
            requestType,
            endPoint,
            body,
            object : CallbackListener<JSONObject>() {
                override fun onSuccess(response: JSONObject) {
                    Log.d("callExtension", "onSuccess: ${response.toString()}")
                    result.success(response.toString())
                }

                override fun onError(e: CometChatException) {
                    Log.d("callExtension", "onError: ${e.message}")
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun blockUsers(call: MethodCall, result: Result) {
        val uids: List<String> = call.argument("uids")!!
        CometChat.blockUsers(uids, object : CallbackListener<HashMap<String, String>>() {
            override fun onSuccess(resultMap: HashMap<String, String>) {
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("blockUser", "onError: ${e.message}")
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun unblockUsers(call: MethodCall, result: Result) {
        val uids: List<String> = call.argument("uids")!!
        CometChat.unblockUsers(
            uids,
            object : CallbackListener<HashMap<String, String>>() {
                override fun onSuccess(resultMap: HashMap<String, String>) {
                    result.success(resultMap)
                }

                override fun onError(e: CometChatException) {
                    Log.d("blockUser", "onError: ${e.message}")
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun fetchBlockedUsers(call: MethodCall, result: Result) {
        val searchTerm: String = call.argument("searchKeyword") ?: ""
        val direction: String = call.argument("direction") ?: ""
        val limit: Int = call.argument("limit") ?: -1
        var key: String? = call.argument("key")
        val setPage: Int = call.argument("setPage") ?: 0

        lateinit var  blockedUsersRequest : BlockedUsersRequest

        if( key==null || !blockedUsersRequestMap.contains(key) || ((blockedUsersRequestMap.get(key))==null) ){
            var builder: BlockedUsersRequest.BlockedUsersRequestBuilder  =  BlockedUsersRequest.BlockedUsersRequestBuilder()
            if (limit > 0) builder = builder.setLimit(limit)
            builder = builder.setPage(setPage)
            if (searchTerm.isNotEmpty()) builder = builder.setSearchKeyword(searchTerm)
            if (direction.isNotEmpty()) {
                if(direction.equals("blockedByMe" ,ignoreCase = true)){
                    builder = builder.setDirection(BlockedUsersRequest.DIRECTION_BLOCKED_BY_ME)
                }else if(direction.equals("hasBlockedMe" ,ignoreCase = true)){
                    builder = builder.setDirection(BlockedUsersRequest.DIRECTION_HAS_BLOCKED_ME)
                }else{
                    builder = builder.setDirection(BlockedUsersRequest.DIRECTION_BOTH)
                }
            }
            blockedUsersRequest= builder.build()
            if(key==null){
                counter++
                key = counter.toString()
            }
            blockedUsersRequestMap[key] = blockedUsersRequest
        }else{
            blockedUsersRequest =   blockedUsersRequestMap[key]!!
        }

        blockedUsersRequest.fetchNext(object : CallbackListener<List<User>>() {
            override fun onSuccess(users: List<User>) {
                Log.d("fetchBlockedUsers", "Blocked users list fetched successfully: " + users.size)
                val list = users.map { e -> getUserMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("fetchBlockedUsers", "Blocked users list fetching failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun fetchUsers(call: MethodCall, result: Result) {
        val searchTerm: String = call.argument("searchTerm") ?: ""
        val limit: Int = call.argument("limit") ?: -1
        val hidebloackedUsers: Boolean = call.argument("hidebloackedUsers") ?: false
        val userRoles: List<String> = call.argument("userRoles")?: emptyList()
        val friendsOnly: Boolean = call.argument("friendsOnly") ?: false
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val uids: List<String> = call.argument("uids") ?: emptyList()
        val withTags: Boolean = call.argument("withTags") ?: false
        val userStatus: String = call.argument("userStatus") ?: ""
        var key: String? = call.argument("key")
        val searchIn: List<String> = call.argument("searchIn") ?: emptyList()
        val sortBy: String = call.argument("sortBy") ?: ""
        val sortByOrder: String = call.argument("sortByOrder") ?: ""
        val setPage: Int = call.argument("setPage") ?: 0
        lateinit var  usersRequest: UsersRequest

        if( key==null || !userRequestMap.contains(key) || ((userRequestMap.get(key))==null) ){
            var builder: UsersRequest.UsersRequestBuilder  =  UsersRequest.UsersRequestBuilder()
            if (limit > 0) builder = builder.setLimit(limit)
            if (searchTerm.isNotEmpty()) builder = builder.setSearchKeyword(searchTerm)
            if (hidebloackedUsers) builder = builder.hideBlockedUsers(hidebloackedUsers)
            if (userRoles.isNotEmpty()) builder = builder.setRoles(userRoles)
            if (friendsOnly) builder = builder.friendsOnly(friendsOnly)
            if (tags.isNotEmpty()) builder = builder.setTags(tags)
            if (uids.isNotEmpty()) builder = builder.setUIDs(uids)
            builder = builder.setPage(setPage)
            if (withTags) builder = builder.withTags(withTags)
            if (userStatus.isNotEmpty()) {
                if(userStatus.equals("online" ,ignoreCase = true)){
                    Log.d("Native UserStatus", "${UsersRequest.USER_STATUS_ONLINE}")
                    builder = builder.setUserStatus(UsersRequest.USER_STATUS_ONLINE)
                }else{
                    Log.d("Native UserStatus", "${UsersRequest.USER_STATUS_OFFLINE}")
                    builder = builder.setUserStatus(UsersRequest.USER_STATUS_OFFLINE)
                }
            }
            if (searchIn.isNotEmpty()) builder = builder.searchIn(searchIn)
            if (sortBy.isNotEmpty()) {
                builder = builder.sortBy(sortBy)
            }
            if (sortByOrder.isNotEmpty()) {
                builder = builder.sortByOrder(sortByOrder)
            }
            usersRequest = builder.build()
            if(key==null){
                counter++
                key = counter.toString()
            }
            userRequestMap[key] = usersRequest
        }else{
            usersRequest =   userRequestMap[key]!!
        }

        usersRequest.fetchNext(object : CallbackListener<List<User>>() {
            override fun onSuccess(members: List<User>) {
                Log.d("fetchUsers", "user Member list fetched successfully: " + members.size)
                val list = members.map { e -> getUserMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("fetchUsers", "User Member list fetching failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun startTyping(call: MethodCall, result: Result) {
        val uid: String = call.argument("uid") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val typingIndicator =TypingIndicator(uid,receiverType)
        CometChat.startTyping(typingIndicator)
    }

    private fun endTyping(call: MethodCall, result: Result) {
        val uid: String = call.argument("uid") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val typingIndicator =TypingIndicator(uid,receiverType)
        CometChat.endTyping(typingIndicator)
    }

    private fun fetchNextMessages(call: MethodCall, result: Result) {
        val limit: Int = call.argument("limit") ?: -1
        val uid: String = call.argument("uid") ?: ""
        val guid: String = call.argument("guid") ?: ""
        val searchTerm: String = call.argument("searchTerm") ?: ""
        val messageId: Long = call.getLongArg("messageId")
        val timestamp: Long = (call.argument("timestamp") ?: 0).toLong()
        val unread: Boolean = call.argument("unread") ?: false
        val hideblockedUsers: Boolean = call.argument("hideblockedUsers") ?: false
        val updateAfter: Long = (call.argument("updateAfter")  ?: 0).toLong()
        val updatesOnly: Boolean = call.argument("updatesOnly") ?: false
        val categories: List<String> = call.argument("categories")?: emptyList()
        val types: List<String> = call.argument("types") ?: emptyList()
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val hideReplies: Boolean = call.argument("hideReplies") ?: false
        val hideDeletedMessages: Boolean = call.argument("hideDeletedMessages") ?: false
        val withTags: Boolean = call.argument("withTags") ?: false
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val interactionGoalCompletedOnly: Boolean = call.argument("interactionGoalCompletedOnly") ?: false
        var key: String? = call.argument("key")
        var hasReactions: Boolean = call.argument("hasReactions") ?: false
        var hasAttachments: Boolean = call.argument("hasAttachments") ?: false
        var mentionedUids: List<String> = call.argument("mentionedUids")?: emptyList()
        var hasMentions: Boolean = call.argument("hasMentions") ?: false
        var hasLinks: Boolean = call.argument("hasLinks") ?: false

        val mentionsWithTagInfo : Boolean = call.argument("mentionsWithTagInfo") ?: false
        val mentionsWithBlockedInfo: Boolean = call.argument("mentionsWithBlockedInfo") ?: false
        var attachmentTypesString: List<String> = call.argument("attachmentTypes")?: emptyList()
        var withParent: Boolean = call.argument("withParent") ?: false
        var hideQuotedMessages: Boolean = call.argument("hideQuotedMessages") ?: false

        val attachmentTypes = attachmentTypesString.mapNotNull { typeStr ->
            val type = AttachmentType.get(typeStr)
            if (type == null) {
                Log.w("AttachmentType", "Unknown attachment type received from Flutter: $typeStr")
                null
            } else {
                type
            }
        }

        lateinit var  messagesRequest: MessagesRequest

        if( key==null || !messageRequestMap.contains(key) || ((messageRequestMap.get(key))==null) ){
            var builder: MessagesRequest.MessagesRequestBuilder = MessagesRequest.MessagesRequestBuilder()

            if (limit > 0) builder = builder.setLimit(limit)

            if (uid.isNotEmpty()) {
                builder = builder.setUID(uid)
            } else if (guid.isNotEmpty()) {
                builder = builder.setGUID(guid)
            }

            if (searchTerm.isNotEmpty()) builder = builder.setSearchKeyword(searchTerm)

            if (messageId > 0) builder = builder.setMessageId(messageId)

            if (timestamp > 0) builder = builder.setTimestamp(timestamp as Long)

            if (unread) {
                builder = builder.setUnread(unread)
            }

            if (hideblockedUsers) builder = builder.hideMessagesFromBlockedUsers(hideblockedUsers)

            if (updateAfter>0) builder = builder.setUpdatedAfter(updateAfter)

            if (updatesOnly) builder = builder.updatesOnly(updatesOnly)

            if (categories.isNotEmpty()) builder = builder.setCategories(categories)

            if (types.isNotEmpty()) builder = builder.setTypes(types)

            if (parentMessageId > 0) builder = builder.setParentMessageId(parentMessageId)

            if (hideReplies) builder = builder.hideReplies(hideReplies)

            if (hideDeletedMessages) builder = builder.hideDeletedMessages(hideDeletedMessages)

            if(withTags) builder  =  builder.withTags(withTags)

            if(tags.isNotEmpty()) builder = builder.setTags(tags)

            if(hasAttachments) builder = builder.hasAttachments(hasAttachments)

            if(hasLinks) builder = builder.hasLinks(hasLinks)

            if(hasReactions) builder = builder.hasReactions(hasReactions)

            if(hasMentions) builder = builder.hasMentions(hasMentions)

            if(mentionedUids.isNotEmpty()) builder = builder.setMentionedUIDs(mentionedUids)

            if(attachmentTypes.isNotEmpty()) builder = builder.setAttachmentTypes(attachmentTypes)

            if(withParent) builder = builder.withParent(withParent)

            if(hideQuotedMessages) builder = builder.hideQuotedMessages(hideQuotedMessages)

            builder = builder.mentionsWithTagInfo(mentionsWithTagInfo).mentionsWithBlockedInfo(mentionsWithBlockedInfo)
            if(interactionGoalCompletedOnly) builder  =  builder.setInteractionGoalCompletedOnly(interactionGoalCompletedOnly)

            messagesRequest= builder.build()

            if(key==null){
                counter++
                key = counter.toString()
            }

            messageRequestMap[key] = messagesRequest
        }else{
            messagesRequest =   messageRequestMap[key]!!
        }

        messagesRequest.fetchNext(object : CallbackListener<List<BaseMessage>>() {
            override fun onSuccess(messages: List<BaseMessage>) {
                val list = messages.map { e -> getMessageMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d(
                    "fetchNextMessages",
                    "Message fetching failed with exception: " + e.message
                )
                result.error(e.code!!, e.message, e.details)
            }
        })
    }


    private fun getUnreadMessageCountForGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val hideMessagesFromBlockedUsers: Boolean = call.argument("hideMessagesFromBlockedUsers") ?: false

        CometChat.getUnreadMessageCountForGroup( guid, hideMessagesFromBlockedUsers , object :
            CallbackListener<HashMap<String, Int>>() {
            override fun onSuccess(counts: HashMap<String,  Int>?) {
                Log.d("getUnreadMessageCount", "onSuccess: $counts")
                result.success(counts)
            }

            override fun onError(e: CometChatException) {
                Log.d("getUnreadMessageCount", "onError: ${e.message}")
                result.error(e.code!!, e.message, e.details)
            }
        })
    }


    private fun getUnreadMessageCountForAllUsers(call: MethodCall, result: Result) {
        val hideMessagesFromBlockedUsers: Boolean = call.argument("hideMessagesFromBlockedUsers") ?: false

        CometChat.getUnreadMessageCountForAllUsers(hideMessagesFromBlockedUsers , object :
            CallbackListener<HashMap<String, Int>>() {
            override fun onSuccess(counts: HashMap<String,  Int>?) {
                Log.d("getUnreadMessageCount", "onSuccess: $counts")
                result.success(counts)
            }

            override fun onError(e: CometChatException) {
                Log.d("getUnreadMessageCount", "onError: ${e.message}")
                result.error(e.code!!, e.message, e.details)
            }
        })
    }


    private fun getUnreadMessageCountForAllGroups(call: MethodCall, result: Result) {
        val hideMessagesFromBlockedUsers: Boolean = call.argument("hideMessagesFromBlockedUsers") ?: false

        CometChat.getUnreadMessageCountForAllGroups(hideMessagesFromBlockedUsers , object :
            CallbackListener<HashMap<String, Int>>() {
            override fun onSuccess(counts: HashMap<String,  Int>?) {
                Log.d("getUnreadMessageCount", "onSuccess: $counts")
                result.success(counts)
            }

            override fun onError(e: CometChatException) {
                Log.d("getUnreadMessageCount", "onError: ${e.message}")
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun markAsDelivered(call: MethodCall, result: Result) {
        val baseMessageMap: HashMap<String, Any?> = call.argument("baseMessage") ?: HashMap()
        var baseMessageObj:BaseMessage = toBaseMessage(baseMessageMap);
        Log.d("markAsDelivered", "Marking delivered : " + "success")

        CometChat.markAsDelivered(baseMessageObj, object : CallbackListener<Void?>() {
            override fun onSuccess(unused: Void?) {
                Log.d("markAsDelivered", "markAsDelivered : " + "success")
                result.success("Success")
            }

            override fun onError(e: CometChatException) {
                Log.e("error", "markAsRead : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun getMessageReceipts(call: MethodCall, result: Result) {
        val messageId: Long = call.argument<Number>("id")?.toLong() ?: -1L
        CometChat.getMessageReceipts(
            messageId,
            object : CallbackListener<List<MessageReceipt?>?>() {
                override fun onSuccess(messageReceipts: List<MessageReceipt?>?) {
                    val list = messageReceipts?.map { e -> getMessageReceiptMap(e) }
                    result.success(list)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun editMessage(call: MethodCall, result: Result) {
        val baseMessageMap: HashMap<String, Any?> = call.argument(BaseMessageConstants.baseMessage) ?: HashMap()
        var updatedMessage:BaseMessage
        if(baseMessageMap[BaseMessageConstants.type]==CometChatConstants.MESSAGE_TYPE_TEXT){
            updatedMessage = toTextMessage(baseMessageMap)
        }else if(baseMessageMap[BaseMessageConstants.type]==CometChatConstants.MESSAGE_TYPE_IMAGE ||baseMessageMap[BaseMessageConstants.type]==CometChatConstants.MESSAGE_TYPE_AUDIO||baseMessageMap[BaseMessageConstants.type]==CometChatConstants.MESSAGE_TYPE_VIDEO||baseMessageMap[BaseMessageConstants.type]==CometChatConstants.MESSAGE_TYPE_FILE){
            updatedMessage = toMediaMessage(baseMessageMap)
        }else if(baseMessageMap[BaseMessageConstants.category]==CometChatConstants.CATEGORY_CUSTOM){
            updatedMessage = toCustomMessage(baseMessageMap)
        }else {
            updatedMessage = toBaseMessage(baseMessageMap)
        }

        CometChat.editMessage(updatedMessage, object : CallbackListener<BaseMessage>() {
            override fun onSuccess(message: BaseMessage) {
                Log.d("TAG", "Message Edited successfully: $message")
                result.success(getMessageMap(message))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun deleteConversation(call: MethodCall, result: Result) {
        val conversationWith: String = call.argument("conversationWith") ?: ""
        val conversationType: String = call.argument("conversationType") ?: ""

        CometChat.deleteConversation(
            conversationWith,
            conversationType,
            object : CallbackListener<String?>() {
                override fun onSuccess(s: String?) {
                    Log.d("TAG", "Message Edited successfully: $s")
                    result.success(s)
                }

                override fun onError(e: CometChatException) {
                    result.error(e.code!!, e.message, e.details)
                }
            }
        )
    }

    private fun sendTransientMessage(call: MethodCall, result: Result) {
        val receiverId: String = call.argument("receiverId") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val passedData : HashMap<String, Any> = call.argument("data") ?: HashMap()
        val data = JSONObject()
        for(items in passedData){
            data.put(items.key,items.value)
        }
        try {
            val transientMessage = TransientMessage(receiverId, receiverType, data)
            CometChat.sendTransientMessage(transientMessage)
            result.success("Message Sent ")
        }catch (e: Exception) {
            result.error("ERR", e.message, e.message)
        }
    }

    private fun getOnlineUserCount( result: Result) {
        CometChat.getOnlineUserCount(object : CallbackListener<Int>() {
            override fun onSuccess(count: Int) {
                Log.d("TAG", "Online users : $count")
                result.success(count)
            }

            override fun onError(e: CometChatException) {
                Log.d("TAG", "Error : " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun updateUser(call: MethodCall, result: Result) {
        val uid: String = call.argument("uid") ?: ""
        val name: String = call.argument("name") ?: ""
        val avatar: String? = call.argument("avatar")
        val tags: List<String>? = call.argument("tags")
        val link: String? = call.argument("link")
        val metadata: String? = call.argument("metadata")
        val statusMessage: String? = call.argument("statusMessage")
        val apiKey: String = call.argument("apiKey") ?: ""
        val role: String? = call.argument("role")
        val blockedByMe: Boolean? = call.argument("blockedByMe")
        val hasBlockedMe: Boolean? = call.argument("hasBlockedMe")
        val lastActiveAt: Long? = call.argument("lastActiveAt")
        val status: String? = call.argument("status")
        val user = User();
        user.uid = uid
        if(name.isNotEmpty())user.name = name
        if(avatar!=null)user.avatar = avatar
        if(link!=null)user.link = link
        if(metadata!=null) user.metadata = JSONObject(metadata)
        if(tags!=null) user.tags = tags
        if(statusMessage!=null)user.statusMessage = statusMessage
        if(role!=null)user.role = role
        if(blockedByMe!=null)user.isBlockedByMe = blockedByMe
        if(hasBlockedMe!=null)user.isHasBlockedMe = hasBlockedMe
        if(lastActiveAt!=null)user.lastActiveAt = lastActiveAt
        if (status!=null) {
            if(status.equals("online" ,ignoreCase = true)){
                user.status = CometChatConstants.USER_STATUS_ONLINE;
            }else{
                user.status = CometChatConstants.USER_STATUS_OFFLINE
            }
        }

        CometChat.updateUser(user, apiKey, object : CallbackListener<User>() {
            override fun onSuccess(user: User) {
                Log.d("updateUser", user.toString())
                result.success(getUserMap(user) )
            }

            override fun onError(e: CometChatException) {
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }


    private fun updateCurrentUserDetails(call: MethodCall, result: Result) {
        val name: String = call.argument("name") ?: ""
        val avatar: String? = call.argument("avatar")
        val tags: List<String>? = call.argument("tags")
        val link: String? = call.argument("link")
        val metadata: String? = call.argument("metadata")
        val statusMessage: String? = call.argument("statusMessage")
        val role: String? = call.argument("role")
        val blockedByMe: Boolean? = call.argument("blockedByMe")
        val hasBlockedMe: Boolean? = call.argument("hasBlockedMe")
        val lastActiveAt: Long? = call.argument("lastActiveAt")
        val status: String? = call.argument("status")
        val user = User()
        if(name.isNotEmpty())user.name = name
        if(avatar!=null)user.avatar = avatar
        if(link!=null)user.link = link
        if(metadata!=null) user.metadata = JSONObject(metadata)
        if(tags!=null) user.tags = tags
        if(statusMessage!=null)user.statusMessage = statusMessage
        if(role!=null)user.role = role
        if(blockedByMe!=null)user.isBlockedByMe = blockedByMe
        if(hasBlockedMe!=null)user.isHasBlockedMe = hasBlockedMe
        if(lastActiveAt!=null)user.lastActiveAt = lastActiveAt
        if (status!=null) {
            if(status.equals("online" ,ignoreCase = true)){
                user.status = CometChatConstants.USER_STATUS_ONLINE;
            }else{
                user.status = CometChatConstants.USER_STATUS_OFFLINE
            }

        }
        CometChat.updateCurrentUserDetails(user,  object : CallbackListener<User>() {
            override fun onSuccess(user: User) {
                Log.d("Update Current User", user.toString())
                result.success(getUserMap(user) )
            }

            override fun onError(e: CometChatException) {
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun getGroup(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        CometChat.getGroup(GUID, object : CallbackListener<Group>() {
            override fun onSuccess(group: Group) {
                Log.d("TAG", "Group details fetched successfully: $group")
                result.success(getGroupMap(group))
            }

            override fun onError(e: CometChatException) {
                Log.d("TAG", "Group details fetching failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun getOnlineGroupMemberCount(call: MethodCall, result: Result) {
        val GUIDS: List<String> = call.argument("guids")?: emptyList()
        CometChat.getOnlineGroupMemberCount(
            GUIDS,
            object : CallbackListener<HashMap<String, Int>>() {
                override fun onSuccess(stringIntegerHashMap: HashMap<String, Int>) {
                    Log.d("TAG", "Group details fetched successfully: $stringIntegerHashMap")
                    result.success(stringIntegerHashMap)
                }

                override fun onError(e: CometChatException) {
                    Log.d("TAG", "Group details fetching failed with exception: " + e.message)
                    result.error(e.message!!, e.message, e.toString())
                }
            }
        )
    }

    private fun updateGroup(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val owner: String = call.argument("owner") ?: ""
        val name: String = call.argument("name") ?: ""
        val icon: String = call.argument("icon") ?: ""
        val description: String = call.argument("description") ?: ""
        val membersCount: Int = call.argument("membersCount")?: 0
        val createdAt: Long? = call.argument("createdAt")
        val joinedAt: Long? = call.argument("joinedAt")
        val updatedAt: Long? = call.argument("updatedAt")
        val tags: List<String>? = call.argument("tags")
        val type: String = call.argument("type") ?: ""
        val password: String = call.argument("password") ?: ""
        val scope: String = call.argument("scope") ?: ""
        val metadata: String? = call.argument("metadata")
        val group = Group()
        if(guid.isNotEmpty())group.guid = guid
        if(owner.isNotEmpty())group.owner = owner
        if(name.isNotEmpty())group.name = name
        if(icon.isNotEmpty())group.icon = icon
        if(description.isNotEmpty())group.description = description
        if(metadata!=null&& metadata.isNotEmpty()){
            group.metadata = JSONObject(metadata)
        }
        if(membersCount!=0) group.membersCount = membersCount
        if(createdAt!=null)group.createdAt = createdAt
        if(joinedAt!=null)group.joinedAt = joinedAt
        if(updatedAt!=null)group.updatedAt = updatedAt
        if(tags!=null) group.tags = tags
        if(type.isNotEmpty())group.groupType = type
        if(password.isNotEmpty())group.password = password
        if(scope.isNotEmpty())group.scope = scope

        CometChat.updateGroup(group, object : CallbackListener<Group>() {
            override fun onSuccess(group: Group) {
                Log.d("TAG", "Groups details updated successfully: $group")
                result.success(getGroupMap(group))
            }

            override fun onError(e: CometChatException) {
                Log.d("TAG", "Group details update failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun addMembersToGroup(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val groupMembers: List<HashMap<String,Any?>> = call.argument("groupMembers")?: emptyList()
        val members: MutableList<GroupMember>  = ArrayList()
        for (item in groupMembers){
            members.add(toGroupMember(item))
        }
        CometChat.addMembersToGroup(
            GUID,
            members,
            null,
            object : CallbackListener<HashMap<String?, String?>?>() {
                override fun onSuccess(successMap: HashMap<String?, String?>?) {
                    Log.d("CometChatActivity", "$successMap")
                    result.success(successMap)
                }

                override fun onError(e: CometChatException) {
                    result.error(e.message!!, e.message, e.toString())
                }
            }
        )
    }

    private fun kickGroupMember(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val UID: String = call.argument("uid") ?: ""

        CometChat.kickGroupMember(UID, GUID, object : CallbackListener<String?>() {
            override fun onSuccess(successMessage: String?) {
                Log.d("TAG", "Group member kicked successfully")
                result.success(successMessage)
            }
            override fun onError(e: CometChatException) {
                Log.d("TAG", "Group member kicking failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun banGroupMember(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val UID: String = call.argument("uid") ?: ""

        CometChat.banGroupMember(UID, GUID, object : CallbackListener<String?>() {
            override fun onSuccess(successMessage: String?) {
                Log.d("TAG", "Group member banned successfully")
                result.success(successMessage)
            }
            override fun onError(e: CometChatException) {
                Log.d("TAG", "Group member ban failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }


    private fun unbanGroupMember(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val UID: String = call.argument("uid") ?: ""

        CometChat.unbanGroupMember(UID, GUID, object : CallbackListener<String?>() {
            override fun onSuccess(successMessage: String?) {
                Log.d("TAG", "Group member Unbanned successfully")
                result.success(successMessage)
            }
            override fun onError(e: CometChatException) {
                Log.d("TAG", "Group member unban failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun updateGroupMemberScope(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val UID: String = call.argument("uid") ?: ""
        val passedScope: String = call.argument("scope") ?: ""
        var scope:String = CometChatConstants.SCOPE_PARTICIPANT
        if(passedScope=="admin")scope = CometChatConstants.SCOPE_ADMIN
        else if(passedScope=="moderator")scope = CometChatConstants.SCOPE_MODERATOR

        CometChat.updateGroupMemberScope(UID, GUID, scope, object : CallbackListener<String?>() {
            override fun onSuccess(successMessage: String?) {
                Log.d("TAG", "User scope updated successfully")
                result.success(successMessage)
            }

            override fun onError(e: CometChatException) {
                Log.d("TAG", "User scope update failed with exception: " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun transferGroupOwnership(call: MethodCall, result: Result) {
        val GUID: String = call.argument("guid") ?: ""
        val UID: String = call.argument("uid") ?: ""

        CometChat.transferGroupOwnership(GUID, UID, object : CallbackListener<String?>() {
            override fun onSuccess(successMessage: String?) {
                Log.e("TAG", "Transfer group ownership successful")
                result.success(successMessage)
            }

            override fun onError(e: CometChatException) {
                Log.e("TAG", "Transfer group ownership failed : " + e.message)
                result.error(e.message!!, e.message, e.toString())
            }
        })
    }

    private fun fetchBlockedGroupMembers(call: MethodCall, result: Result) {
        val searchTerm: String = call.argument("searchKeyword") ?: ""
        val limit: Int = call.argument("limit") ?: -1
        val guid: String = call.argument("guid") ?: ""
        val scopes: List<String> = call.argument("scopes")?: emptyList()
        var key: String? = call.argument("key")
        val setPage: Int = call.argument("setPage") ?: 0

        lateinit var  bannedGroupMembersRequest: BannedGroupMembersRequest

        if( key==null || !bannedGroupMemberRequestMap.contains(key) || ((bannedGroupMemberRequestMap.get(key))==null) ){
            var builder: BannedGroupMembersRequest.BannedGroupMembersRequestBuilder  =  BannedGroupMembersRequest.BannedGroupMembersRequestBuilder(guid)
            if (limit > 0) builder = builder.setLimit(limit)
            if (searchTerm.isNotEmpty()) builder = builder.setSearchKeyword(searchTerm)
            if (scopes.isNotEmpty()) builder = builder.setScopes(scopes)
            builder = builder.setPage(setPage)
            bannedGroupMembersRequest= builder.build()
            if(key==null){
                counter++
                key = counter.toString()
            }
            bannedGroupMemberRequestMap[key] = bannedGroupMembersRequest
        }else{
            bannedGroupMembersRequest =   bannedGroupMemberRequestMap[key]!!
        }
        bannedGroupMembersRequest.fetchNext(object : CallbackListener<List<GroupMember>>() {
            override fun onSuccess(members: List<GroupMember>) {
                Log.d("fetchUsers", "user Member list fetched successfully: " + members.size)
                val list = members.map { e -> getGroupMemberMap(e) }
                val resultMap = mutableMapOf<String, Any?>()
                resultMap["key"] = key
                resultMap["list"] = list
                result.success(resultMap)
            }

            override fun onError(e: CometChatException) {
                Log.d("fetchUsers", "User Member list fetching failed with exception: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun tagConversation(call: MethodCall, result: Result) {
        val conversationWith: String = call.argument("conversationWith") ?: ""
        val conversationType: String = call.argument("conversationType") ?: ""
        val tags: List<String> = call.argument("tags") ?: emptyList()

        CometChat.tagConversation(conversationWith, conversationType, tags,object: CallbackListener<Conversation>(){
            override fun onSuccess(conversation: Conversation) {
                Log.d("Edit Tag", "${conversation.tags}")
                result.success(getConversationMap(conversation))
            }
            override fun onError(e: CometChatException) {
                Log.e("getConversation", "Failed to fetch conversation: " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun connect(result: Result) {
        CometChat.connect()
    }

    private fun connectNew(result: Result) {
        var hasResponded = false

        try {
            CometChat.connect(object : CallbackListener<String>(){
                override fun onSuccess(p0: String?) {
                    if (!hasResponded) {
                        hasResponded = true
                        result.success(p0)
                    }
                }

                override fun onError(p0: CometChatException) {
                    if (!hasResponded) {
                        hasResponded = true
                        result.error(p0.code, p0.message, p0.details)
                    }
                }
            })
        } catch (e: Exception) {
            if (!hasResponded) {
                hasResponded = true
                result.error("ERROR", e.message, e.toString())
            }
        }
    }

    private fun disconnect(result: Result) {
        CometChat.disconnect()
    }

    private fun disconnectNew(result: Result) {
        try {
            CometChat.disconnect(object : CallbackListener<String>(){
                override fun onSuccess(p0: String?) {
                    result.success(p0)
                }

                override fun onError(p0: CometChatException) {
                    result.error(p0.code, p0.message, p0.details)
                }
            })
        }catch (e: Exception){
            result.error("ERROR", e.message, e.toString())
        }
    }

    private fun getConnectionStatus( result: Result) {
        val connectionStatus : String =  CometChat.getConnectionStatus()
        result.success(connectionStatus)
    }

    private fun toBaseMessage(map : HashMap<String, Any?>):BaseMessage{
        val baseMesssageObject:BaseMessage  = BaseMessage();
        baseMesssageObject.id = (map["id"] as? Number)?.toLong() ?: 0L
        baseMesssageObject.receiverUid = map["receiverUid"] as String
        baseMesssageObject.type = map["type"] as String
        baseMesssageObject.receiverType = map["receiverType"] as String
        baseMesssageObject.parentMessageId = (map["parentMessageId"] as? Number)?.toLong() ?: 0L
        baseMesssageObject.category = map["category"] as String
        baseMesssageObject.sender = toUser(map["sender"] as HashMap<String, Any?>) as User
        if(baseMesssageObject.receiverType=="group"){
            baseMesssageObject.receiver = toGroup(map["receiver"] as HashMap<String, Any?>) as Group
        }else{
            baseMesssageObject.receiver = toUser(map["receiver"] as HashMap<String, Any?>) as User
        }

        if (map["quotedMessageId"] != null) {
            baseMesssageObject.quotedMessageId = (map["quotedMessageId"] as? Number)?.toLong() ?: 0L
        }
        if (map["quotedMessage"] != null) {
            try {
                @Suppress("UNCHECKED_CAST")
                val quotedMap = map["quotedMessage"] as HashMap<String, Any?>
                baseMesssageObject.quotedMessage = toBaseMessage(quotedMap)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("CometChat", "Failed to parse quotedMessage: ${e.message}")
            }
        }
        return baseMesssageObject;
    }

    private fun toTextMessage(map : HashMap<String, Any?>):TextMessage{
        val textMessage  = TextMessage(map["receiverUid"] as String ,map["type"] as String,map["receiverType"] as String  );
        textMessage.id = (map["id"] as? Number)?.toLong() ?: 0L
        textMessage.text = map["text"] as String
        textMessage.receiverUid = map["receiverUid"] as String
        textMessage.type = map["type"] as String
        textMessage.receiverType = map["receiverType"] as String
        textMessage.parentMessageId = (map["parentMessageId"] as? Number)?.toLong() ?: 0L
        textMessage.category = map["category"] as String
        if(map["sender"] != null) {
            textMessage.sender = toUser(map["sender"] as HashMap<String, Any?>) as User
        }
        if(textMessage.receiverType=="group"){
            if(map["receiver"] != null) {
                textMessage.receiver = toGroup(map["receiver"] as HashMap<String, Any?>) as Group
            }
        }else{
            if(map["receiver"] != null) {
                textMessage.receiver = toUser(map["receiver"] as HashMap<String, Any?>) as User
            }
        }
        if(map["tags"]==null)textMessage.tags = emptyList()
        else  textMessage.tags = map["tags"]as MutableList<String>

        val metadata = map["metadata"] as HashMap<String, Any?>?;
        if(metadata!=null&& metadata.isNotEmpty()){
            textMessage.metadata = JSONObject(metadata)
            //Log.d("Meta data in android", "before sending meta data = ${textMessage.metadata}")
        }
        return textMessage;
    }

    private fun toCustomMessage(map : HashMap<String, Any?>):CustomMessage{
        val customMessageJson: JSONObject;
        val customData = map["customData"] as HashMap<String, Any?>?;
        customMessageJson = if(customData!=null&& customData.isNotEmpty()){
            JSONObject(customData)
        }else{
            JSONObject("""{}""")
        }

        val custom  = CustomMessage(map["receiverUid"] as String ,map["type"] as String,map["receiverType"] as String ,customMessageJson );
        custom.id = (map["id"] as? Number)?.toLong() ?: 0L
        custom.receiverUid = map["receiverUid"] as String
        custom.type = map["type"] as String
        custom.receiverType = map["receiverType"] as String
        custom.parentMessageId = (map["parentMessageId"] as? Number)?.toLong() ?: 0L
        custom.category = map["category"] as String
        custom.sender = toUser(map["sender"] as HashMap<String, Any?>) as User
        if(custom.receiverType=="group"){
            custom.receiver = toGroup(map["receiver"] as HashMap<String, Any?>) as Group
        }else{
            custom.receiver = toUser(map["receiver"] as HashMap<String, Any?>) as User
        }
        if(map["tags"]==null)custom.tags = emptyList()
        else  custom.tags = map["tags"]as MutableList<String>

        val metadata = map["metadata"] as HashMap<String, Any?>?;
        if(metadata!=null&& metadata.isNotEmpty()){
            custom.metadata = JSONObject(metadata)
        }
        return custom;
    }

    private fun toMediaMessage(map : HashMap<String, Any?>):MediaMessage{
        val mediaMessage  = MediaMessage(map[MediaMessageConstants.receiverUid] as String ,map[MediaMessageConstants.type] as String,map[MediaMessageConstants.receiverType] as String  );
        mediaMessage.id = (map[MediaMessageConstants.id] as? Number)?.toLong() ?: 0L
        mediaMessage.receiverUid = map[MediaMessageConstants.receiverUid] as String
        mediaMessage.type = map[MediaMessageConstants.type] as String
        mediaMessage.receiverType = map[MediaMessageConstants.receiverType] as String
        mediaMessage.parentMessageId = (map[MediaMessageConstants.parentMessageId] as? Number)?.toLong() ?: 0L
        mediaMessage.category = map[MediaMessageConstants.category] as String
        mediaMessage.sender = toUser(map[MediaMessageConstants.sender] as HashMap<String, Any?>) as User
        if(mediaMessage.receiverType==CometChatConstants.RECEIVER_TYPE_GROUP){
            mediaMessage.receiver = toGroup(map[MediaMessageConstants.receiver] as HashMap<String, Any?>) as Group
        }else{
            mediaMessage.receiver = toUser(map[MediaMessageConstants.receiver] as HashMap<String, Any?>) as User
        }
        if(map[MediaMessageConstants.tags]==null) mediaMessage.tags = emptyList()
        else  mediaMessage.tags = map[MediaMessageConstants.tags]as MutableList<String>

        val metadata = map[MediaMessageConstants.metadata] as HashMap<String, Any?>?;
        if(metadata!=null&& metadata.isNotEmpty()){
            mediaMessage.metadata = JSONObject(metadata)
        }
        return mediaMessage;
    }

    private fun toUser(map : HashMap<String, Any?>):User{
        val userObj:User  = User();
        userObj.uid = map["uid"] as String
        userObj.name = map["name"] as String
        userObj.status = map["status"] as String?
        return userObj;
    }

    private fun toGroup(map : HashMap<String, Any?>):Group{
        val groupObj:Group  = Group()
        groupObj.guid = map["guid"] as String
        groupObj.name = map["name"] as String
        return groupObj
    }

    private fun toGroupMember(map : HashMap<String, Any?>):GroupMember{
        val groupMember:GroupMember
        if(map["scope"] as String == "admin") groupMember  = GroupMember(map["uid"] as String,CometChatConstants.SCOPE_ADMIN)
        else if(map["scope"] as String == "moderator") groupMember  = GroupMember(map["uid"] as String,CometChatConstants.SCOPE_MODERATOR)
        else groupMember  = GroupMember(map["uid"] as String,CometChatConstants.SCOPE_PARTICIPANT);
        return groupMember
    }

    private fun getLastDeliveredMessageId(call: MethodCall, result: Result) {
        val lastDeliveredMessageId:Long = CometChat.getLastDeliveredMessageId();
        result.success(lastDeliveredMessageId);
    }

    //Call-SDK-changes
    private fun getUserAuthToken(result: Result) {
        val token: String? = CometChat.getUserAuthToken()
        if (token.isNullOrBlank()){
            result.error("ERROR", "User auth token is null", "User is not logged in.")
        }else{
            result.success(token)
        }
    }

    private fun initiateCall(args: MethodCall, result: Result) {
        val receiverUid = args.argument<String>("receiverUid")
        val receiverType = args.argument<String>("receiverType")
        val callType = args.argument<String>("callType")
        val metadata: String = args.argument("metadata") ?: ""
        val muid: String = args.argument("muid") ?: ""
        val timeout = args.argument<Int>("timeout")

        val call = Call(receiverUid!!, receiverType, callType)

        if(muid.isNotEmpty()) {
            call.muid = muid
        }

        if(metadata.isNotEmpty()){
            call.metadata = JSONObject(metadata)
        }

        val callback = object : CallbackListener<Call>() {
            override fun onSuccess(call: Call) {
                result.success(callToMap(call))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        }

        if (timeout != null) {
            CometChat.initiateCall(call, timeout, callback)
        } else {
            CometChat.initiateCall(call, callback)
        }
    }

    private fun acceptCall(args: MethodCall, result: Result) {
        val sessionID = args.argument<String>("sessionID")
        CometChat.acceptCall(sessionID!!, object : CallbackListener<Call>() {
            override fun onSuccess(call: Call) {
                result.success(callToMap(call))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun rejectCall(args: MethodCall, result: Result) {
        val sessionID = args.argument<String>("sessionID")
        val status = args.argument<String>("status")
        CometChat.rejectCall(sessionID!!, status!!, object : CallbackListener<Call>() {
            override fun onSuccess(call: Call) {
                result.success(callToMap(call))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun endCall(args: MethodCall, result: Result) {
        val sessionID = args.argument<String>("sessionID")
        CometChat.endCall(sessionID!!, object : CallbackListener<Call>() {
            override fun onSuccess(call: Call) {
                result.success(callToMap(call))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun getActiveCall(result: Result){
        try {
            val activeCallObj = CometChat.getActiveCall()
            if(activeCallObj != null){
                result.success(callToMap(activeCallObj))
            }else{
                result.success(null)
            }
        }catch (e: Exception){
            result.error("ERROR", e.message, e.toString())
        }
    }

    private fun clearActiveCall(result: Result){
        try {
            CometChat.clearActiveCall()
            result.success(true)
        }catch (e: Exception){
            result.error("ERROR", e.message, e.toString())
        }
    }

    private fun ping(result: Result){
        try {
            CometChat.ping(object : CallbackListener<String>() {
                override fun onSuccess(successString: String?) {
                    Log.d("ping", "Initialization completed successfully")
                    result.success(successString)
                }

                override fun onError(e: CometChatException) {
                    Log.d("ping", "Initialization failed with exception: " + e.message)
                    result.error(e.code, e.message, e.details)
                }
            })
        }catch (e: Exception){
            result.error("ERROR", e.message, e.toString())
        }
    }

    private fun addCallListener(){
        CometChat.addCallListener(listenerID, object :CometChat.CallListener(){
            override fun onOutgoingCallAccepted(p0: Call?) {
                val responseMap :HashMap<String,Any?> = HashMap()
                responseMap["call"] = callToMap(p0!!)
                responseMap["methodName"] = "onOutgoingCallAccepted"
                messageStreamSink?.success(responseMap)
            }
            override fun onIncomingCallReceived(p0: Call?) {
                val responseMap :HashMap<String,Any?> = HashMap()
                responseMap["call"] = callToMap(p0!!)
                responseMap["methodName"] = "onIncomingCallReceived"
                messageStreamSink?.success(responseMap)
            }
            override fun onIncomingCallCancelled(p0: Call?) {
                val responseMap :HashMap<String,Any?> = HashMap()
                responseMap["call"] = callToMap(p0!!)
                responseMap["methodName"] = "onIncomingCallCancelled"
                messageStreamSink?.success(responseMap)
            }
            override fun onOutgoingCallRejected(p0: Call?) {
                val responseMap :HashMap<String,Any?> = HashMap()
                responseMap["call"] = callToMap(p0!!)
                responseMap["methodName"] = "onOutgoingCallRejected"
                messageStreamSink?.success(responseMap)
            }
            override fun onCallEndedMessageReceived(p0: Call?) {
                val responseMap :HashMap<String,Any?> = HashMap()
                responseMap["call"] = callToMap(p0!!)
                responseMap["methodName"] = "onCallEndedMessageReceived"
                messageStreamSink?.success(responseMap)
            }
        })
    }


    private fun callToMap(call: Call): HashMap<String, Serializable?> {
        val metaData: String? = if(call.metadata != null){
            call.metadata.toString()
        }else{
            null
        }
        return hashMapOf(
            "sessionId" to call.sessionId,
            "callStatus" to call.callStatus,
            "action" to call.action,
            "rawData" to call.rawData,
            "initiatedAt" to call.initiatedAt,
            "joinedAt" to call.joinedAt,
            "callInitiator" to when (call.callInitiator) {
                is User -> getUserMap(call.callInitiator as User)
                is Group -> getGroupMap(call.callInitiator as Group)
                else -> null
            },
            "callReceiver" to when (call.callReceiver) {
                is User -> getUserMap(call.callReceiver as User)
                is Group -> getGroupMap(call.callReceiver as Group)
                else -> null
            },
            "id" to call.id,
            "muid" to call.muid,
            "sender" to when (call.sender) {
                is User -> getUserMap(call.sender as User)
                is Group -> getGroupMap(call.sender as Group)
                else -> null
            },
            "receiver" to when (call.receiver) {
                is User -> getUserMap(call.receiver as User)
                is Group -> getGroupMap(call.receiver as Group)
                else -> null
            },
            "receiverUid" to call.receiverUid,
            "type" to call.type,
            "receiverType" to call.receiverType,
            "category" to call.category,
            "sentAt" to call.sentAt,
            "deliveredAt" to call.deliveredAt,
            "readAt" to call.readAt,
            "metadata" to metaData,
            "readByMeAt" to call.readByMeAt,
            "deliveredToMeAt" to call.deliveredToMeAt,
            "deletedAt" to call.deletedAt,
            "editedAt" to call.editedAt,
            "deletedBy" to call.deletedBy,
            "editedBy" to call.editedBy,
            "updatedAt" to call.updatedAt,
            "conversationId" to call.conversationId,
            "parentMessageId" to call.parentMessageId,
            "replyCount" to call.replyCount
        )
    }

    private fun errorToMap(e: CometChatException): HashMap<String, Serializable?> {
        return hashMapOf(
            "code" to e.code,
            "details" to e.details,
            "message" to e.message,
        )
    }

    private fun getMessageReactionMap(messageReaction: Reaction): HashMap<String, Serializable?> {
        return hashMapOf(
            "reactionId" to messageReaction.reactionId,
            "messageId" to messageReaction.messageId,
            "reaction" to messageReaction.reaction,
            "uid" to messageReaction.uid,
            "reactedAt" to messageReaction.reactedAt,
            "reactedBy" to getUserMap(messageReaction.reactedBy)
        )
    }

    private fun getReactionEventMap(reactionEvent: ReactionEvent): HashMap<String, Serializable?> {
        return hashMapOf(
                "reaction" to getMessageReactionMap(reactionEvent.reaction),
                "receiverId" to reactionEvent.receiverId,
                "receiverType" to reactionEvent.receiverType,
                "conversationId" to reactionEvent.conversationId,
                "parentMessageId" to reactionEvent.parentMessageId,
        )
    }

    private fun isExtensionEnabled(args: MethodCall,result: Result){
        val extensionId = args.argument<String>("extensionId")
        CometChat.isExtensionEnabled(extensionId!!,
            object : CallbackListener<Boolean>() {
            override fun onSuccess(res: Boolean) {
                result.success(res)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun setSource(args: MethodCall, result: Result){
        val resource = args.argument<String>("resource")
        val platform = args.argument<String>("platform")
        val language = args.argument<String>("language")
        CometChat.setSource(resource!!,platform!!,language!!)
        result.success(true)
    }

    private fun setPlatformParams(args: MethodCall, result: Result){
        val platform: String =  args.argument("platform") ?: ""
        val sdkVersion: String =  args.argument("sdkVersion") ?: ""
        CometChat.setPlatformParams(platform, sdkVersion)
        result.success(true)
    }

    private fun getSmartReplies(args: MethodCall, result: Result){
        val receiverId = args.argument<String>("receiverId")
        val receiverType = args.argument<String>("receiverType")
        val configuration = args.argument<HashMap<* , *>?>("configuration")
        if (configuration == null) {
            CometChat.getSmartReplies(receiverId!!, receiverType!!, object : CallbackListener<HashMap<String, String>>() {
                override fun onSuccess(hasMap: HashMap<String, String>) {
                    result.success(hasMap)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        }else {
            var jsonConfiguration = JSONObject(configuration as Map<* , *>)
            CometChat.getSmartReplies(receiverId!!, receiverType!!, jsonConfiguration, object : CallbackListener<HashMap<String, String>>() {
                override fun onSuccess(hasMap: HashMap<String, String>) {
                    result.success(hasMap)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        }
    }

    private fun getConversationStarter(args: MethodCall, result: Result){
        val receiverId = args.argument<String>("receiverId")
        val receiverType = args.argument<String>("receiverType")
        val configuration = args.argument<HashMap<* , *>?>("configuration")
        if (configuration == null) {
            CometChat.getConversationStarter(receiverId!!, receiverType!!, object : CallbackListener<List<String>>() {
                override fun onSuccess(responseList: List<String>?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        } else {
            var jsonConfiguration = JSONObject(configuration as Map<* , *>)
            CometChat.getConversationStarter(receiverId!!, receiverType!!, jsonConfiguration, object : CallbackListener<List<String>>() {
                override fun onSuccess(responseList: List<String>?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        }
    }

    private fun getConversationSummary(args: MethodCall, result: Result) {
        val receiverId = args.argument<String>("receiverId")
        val receiverType = args.argument<String>("receiverType")
        val configuration = args.argument<HashMap<* , *>?>("configuration")
        if (configuration == null) {
            CometChat.getConversationSummary(receiverId!!, receiverType!!, object: CallbackListener<String>() {
                override fun onSuccess(responseList: String?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        } else {
            var jsonConfiguration = JSONObject(configuration as Map<* , *>)
            CometChat.getConversationSummary(receiverId!!, receiverType!!, jsonConfiguration, object: CallbackListener<String>() {
                override fun onSuccess(responseList: String?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        }
    }

    private fun askBot(args: MethodCall, result: Result) {
        val receiverId = args.argument<String>("receiverId")
        val receiverType = args.argument<String>("receiverType")
        val configuration = args.argument<HashMap<* , *>?>("configuration")
        val botId = args.argument<String>("botId")
        val question = args.argument<String>("question")
        if (configuration == null) {
            CometChat.askBot(receiverId!!, receiverType!!, botId!!, question!!, object: CallbackListener<String>() {
                override fun onSuccess(responseList: String?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        } else {
            var jsonConfiguration = JSONObject(configuration as Map<* , *>)
            CometChat.askBot(receiverId!!, receiverType!!, botId!!, question!!, jsonConfiguration, object: CallbackListener<String>() {
                override fun onSuccess(responseList: String?) {
                    result.success(responseList)
                }
                override fun onError(e: CometChatException) {
                    result.error(e.code, e.message, e.details)
                }
            })
        }
    }

    private fun isAIFeatureEnabled(args: MethodCall, result: Result) {
        val feature = args.argument<String>("feature")
        CometChat.isAIFeatureEnabled(feature!!, object : CallbackListener<Boolean>() {
            override fun onSuccess(isEnabled: Boolean?) {
                result.success(isEnabled)
            }
            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun setMetaInfo(){
        try {
            val jsonObject = JSONObject()
            //Chat SDK
            val chatsdk = JSONObject()
            chatsdk.put("platform", Utils().getPlatform())
            chatsdk.put("version", Utils().getSDKVersion())
            jsonObject.put("chatsdk", chatsdk)
            //Calls SDK
            val callSDKVersion = callMethod("com.cometchatcalls.cometchatcalls_plugin.Utils", "getSDKVersion")
            if (callSDKVersion != null) {
                val callssdk = JSONObject()
                callssdk.put("platform", Utils().getPlatform())
                callssdk.put("version", callSDKVersion)
                jsonObject.put("callssdk", callssdk)
            }
            //Calls UIKIT SDK
            val callUIKitSDKVersion = callMethod("com.cometchat.cometchat_calls_uikit.Utils", "getSDKVersion")
            if (callUIKitSDKVersion != null) {
                val callsuikit = JSONObject()
                callsuikit.put("platform", Utils().getPlatform())
                callsuikit.put("version", callUIKitSDKVersion)
                jsonObject.put("callsuikit", callsuikit)
            }
            //UIKIT SDK
            val uiKitSDKVersion = callMethod("com.cometchat.cometchat_chat_uikit.Utils", "getSDKVersion")
            if (uiKitSDKVersion != null) {
                val uikit = JSONObject()
                uikit.put("platform", Utils().getPlatform())
                uikit.put("version", uiKitSDKVersion)
                jsonObject.put("uikit", uikit)
            }
            CometChat.setMetaInfo(jsonObject)
        }catch (e: Exception) {
            if(BuildConfig.DEBUG){
                Log.e("TAG", "Error: $e")
            }
        }
    }

    private fun setDemoMetaInfo(args: MethodCall, result: Result){
        try {
            val demoMetaInfo = args.argument<Map<String, String>>("demoMetaInfo")
            if(demoMetaInfo.isNullOrEmpty()){
                result.error("Error", "Required data is null", "Required data is null")
            }else{
                val demoMetaInfoJson = mapToJSONObject(demoMetaInfo)
                CometChat.setDemoMetaInfo(demoMetaInfoJson)
                result.success(true)
            }
        }catch (e: Exception) {
            if(BuildConfig.DEBUG){
                Log.e("TAG", "Error: $e")
            }
            result.error("Error", "$e", "$e")
        }
    }

    private fun callMethod(className: String?, methodName: String?): String? {
        var data: String? = null
        try {
            val myClass = Class.forName(className)
            val myMethod = myClass.getMethod(methodName)
            val myObject = myClass.getConstructor().newInstance()
            val result = myMethod.invoke(myObject)
            data = result as String
        } catch (e: Exception) {
            if(BuildConfig.DEBUG){
                Log.e("TAG", "Error: $e")
            }
        }
        return data
    }

    private fun mapToJSONObject(map: Map<String, String>?): JSONObject? {
        try{
            if (map == null) return null
            val jsonObject = JSONObject()
            for (key in map.keys) {
                val value = map[key]
                jsonObject.put(key, value)
            }
            return jsonObject
        }catch (e: Exception){
            return null
        }
    }

    private fun markAsUnread(call: MethodCall, result: Result) {
        val baseMessage: HashMap<String, Any?> = call.argument("baseMessage") ?: HashMap()
        var baseMessageObj:BaseMessage = toBaseMessage(baseMessage);
        CometChat.markAsUnread(baseMessageObj, object : CallbackListener<Void?>() {
            override fun onSuccess(unused: Void?) {
                Log.d("markAsUnread", "markAsUnread : " + "success")
                result.success("Success")
            }

            override fun onError(e: CometChatException) {
                Log.e("error", "markAsUnread : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun sendInteractiveMessage(call: MethodCall, result: Result) {
        val receiverId: String = call.argument("receiverId") ?: ""
        val receiverType: String = call.argument("receiverType") ?: ""
        val type: String = call.argument("type") ?: ""
        val interactiveData: Map<String, Any> = call.argument<Map<String, Any>>("interactiveData") ?: emptyMap()
        val tags: List<String> = call.argument("tags") ?: emptyList()
        val muid: String = call.argument("muid") ?: ""
        val parentMessageId: Long = call.getLongArg("parentMessageId")
        val metadata: String = call.argument("metadata") ?: ""
        val interactionGoalMap: Map<String, Any> = call.argument<Map<String, Any>>("interactionGoal") ?: emptyMap()
        val allowSenderInteraction: Boolean = call.argument("allowSenderInteraction") ?: false
        val quotedMessageId: Long = call.getLongArg("quotedMessageId")
        val jsonObject: JSONObject = JSONObject(interactiveData)
        val interactionGoalJSON: JSONObject = JSONObject(interactionGoalMap)
        val interactionGoal = InteractionGoal.fromJsom(interactionGoalJSON)
        if(interactionGoal.elementIds == null){
            interactionGoal.elementIds = listOf<String>();
        }
        val interactiveMessage = InteractiveMessage(receiverId, receiverType,type, jsonObject )
        interactiveMessage.setInteractionGoal(interactionGoal)
        if(muid!=null && muid.isNotEmpty()) interactiveMessage.muid  = muid;
        if(tags.isNotEmpty()) interactiveMessage.tags = tags
        if (parentMessageId > 0) interactiveMessage.parentMessageId = parentMessageId
        if(metadata.isNotEmpty()){
            interactiveMessage.metadata = JSONObject(metadata)
        }
        if(allowSenderInteraction){
            interactiveMessage.isAllowSenderInteraction = true
        }
        if (quotedMessageId > 0) interactiveMessage.quotedMessageId = quotedMessageId
        CometChat.sendInteractiveMessage(interactiveMessage, object : CallbackListener<InteractiveMessage>() {
            override fun onSuccess(interactiveMessage: InteractiveMessage) {

                val interactiveData:HashMap<String, Any?>? = getMessageMap(interactiveMessage);
                result.success(interactiveData)
            }
            override fun onError(e: CometChatException) {
                //Log.d("TAG", e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun markAsInteracted(call: MethodCall, result: Result) {
        val messageId: Long = call.getLongArg("messageId")
        val interactedElementId: String = call.argument("interactedElementId") ?: ""
        CometChat.markAsInteracted(messageId ,interactedElementId ,object : CallbackListener<Void?>() {
            override fun onSuccess(unused: Void?) {
                result.success("Success")
            }

            override fun onError(e: CometChatException) {
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun addReaction(call: MethodCall, result: Result){
        val messageId: Long = call.getLongArg("messageId")
        val reaction: String ?= call.argument("reaction")
        CometChat.addReaction(messageId, reaction, object : CallbackListener<BaseMessage>(){
            override fun onSuccess(baseMessage: BaseMessage?) {
                result.success(getMessageMap(baseMessage))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun removeReaction(call: MethodCall, result: Result){
        val messageId: Long = call.getLongArg("messageId")
        val reaction: String ?= call.argument("reaction")
        CometChat.removeReaction(messageId, reaction, object : CallbackListener<BaseMessage>(){
            override fun onSuccess(baseMessage: BaseMessage?) {
                result.success(getMessageMap(baseMessage))
            }

            override fun onError(e: CometChatException) {
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun fetchNextAndPreviousForReactionsRequest(call: MethodCall, result: Result) {
        val paginationTask: Int = call.argument("paginationTask")!!
        val limit: Int = call.argument("limit") ?: -1
        val messageId: Long = call.getLongArg("messageId")
        val reaction: String? = call.argument("reaction")
        var key: String? = call.argument("key")

        lateinit var reactionRequest: ReactionsRequest

        if (key == null || !reactionRequestMap.contains(key) || ((reactionRequestMap[key]) == null)) {
            val builder: ReactionsRequest.ReactionsRequestBuilder = ReactionsRequest.ReactionsRequestBuilder()
            if (limit > 0) builder.setLimit(limit)
            if (messageId > 0) builder.setMessageId(messageId)
            if (reaction != null) builder.setReaction(reaction)
            reactionRequest = builder.build()
            if (key == null) {
                counter++
                key = counter.toString()
            }
            reactionRequestMap[key] = reactionRequest
        } else {
            reactionRequest = reactionRequestMap[key]!!
        }
        if (paginationTask == 0){
            reactionRequest.fetchNext(object : CallbackListener<List<Reaction>>(){
                override fun onSuccess(messageReactions: List<Reaction>) {
                    val list = messageReactions.map { e -> getMessageReactionMap(e) }
                    val resultMap = mutableMapOf<String, Any?>()
                    resultMap["key"] = key
                    resultMap["list"] = list
                    result.success(resultMap)
                }

                override fun onError(e: CometChatException) {
                    result.error(e.code!!, e.message, e.details)
                }
            })
        } else {
            reactionRequest.fetchPrevious(object : CallbackListener<List<Reaction>>(){
                override fun onSuccess(messageReactions: List<Reaction>) {
                    val list = messageReactions.map { e -> getMessageReactionMap(e) }
                    val resultMap = mutableMapOf<String, Any?>()
                    resultMap["key"] = key
                    resultMap["list"] = list
                    result.success(resultMap)
                }

                override fun onError(e: CometChatException) {
                    result.error(e.code!!, e.message, e.details)
                }
            })
        }
    }

    private fun fetchPreferences(call: MethodCall, result: Result){
        CometChatNotifications.fetchPreferences(object : CallbackListener<NotificationPreferences>() {
            override fun onSuccess(notificationPreferences: NotificationPreferences) {
                result.success(notificationPreferences.toMap())
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        });
    }

    private fun updatePreferences(call: MethodCall, result: Result){
        val raw = call.arguments
        val requestObj = NotificationPreferences.fromMap(raw as MutableMap<String, Any>?)
        CometChatNotifications.updatePreferences(requestObj, object : CallbackListener<NotificationPreferences>() {
            override fun onSuccess(notificationPreferences: NotificationPreferences) {
                result.success(notificationPreferences.toMap())
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        });
    }

    private fun resetPreferences(call: MethodCall, result: Result){
        CometChatNotifications.resetPreferences(object : CallbackListener<NotificationPreferences>() {
            override fun onSuccess(notificationPreferences: NotificationPreferences) {
                result.success(notificationPreferences.toMap())
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        });
    }

    private fun getMutedConversations(call: MethodCall, result: Result){
        CometChatNotifications.getMutedConversations(object : CallbackListener<List<MutedConversation>>() {
            override fun onSuccess(mutedConversations: List<MutedConversation>) {
                val r1 : MutableMap<Int, MutableMap<String, Any>> = mutableMapOf()
                for ((index, value) in mutedConversations.withIndex()) {
                    r1[index] = mutedConversations[index].toMap()
                }
                result.success(r1)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        });
    }

    private fun muteConversations(call: MethodCall, result: Result){
        val raw = call.arguments
        val requestObj = raw as MutableMap<*, *>?
        val mutedConversation: MutableList<MutedConversation> = arrayListOf()
        requestObj?.forEach { (key, value) ->
            val mutedConversationMap = value as Map<String, Any>?
            val mutedConversationObj = MutedConversation.fromMap(mutedConversationMap)
            mutedConversation.add(mutedConversationObj)
        }
        CometChatNotifications.muteConversations(mutedConversation, object : CallbackListener<String>() {
            override fun onSuccess(response: String?) {
                result.success(response)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        });
    }

    private fun unmuteConversations(call: MethodCall, result: Result){
        val raw = call.arguments
        val requestObj = raw as MutableMap<*, *>?
        val unmuteConversations: MutableList<UnmutedConversation> = arrayListOf()
        requestObj?.forEach {(key, value) ->
            val unmuteConversationMap = value as Map<String, Any>?
            unmuteConversations.add(UnmutedConversation.fromMap(unmuteConversationMap))
        }
        CometChatNotifications.unmuteConversations(unmuteConversations, object : CallbackListener<String>() {
            override fun onSuccess(response: String?) {
                result.success(response)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun registerPushToken(call: MethodCall, result: Result){
        val pushPlatforms: PushPlatforms = PushPlatforms.get(call.argument("pushPlatforms"))
        val fcmToken: String = call.argument("fcmToken") ?: ""
        val providerId: String? = call.argument("providerId")
        CometChatNotifications.registerPushToken(fcmToken, pushPlatforms, providerId, object : CallbackListener<String>() {
            override fun onSuccess(response: String) {
                result.success(response)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun unregisterPushToken(call: MethodCall, result: Result){
        CometChatNotifications.unregisterPushToken(object : CallbackListener<String>() {
            override fun onSuccess(response: String) {
                result.success(response)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun getConversationUpdateSettings(call: MethodCall, result: Result){
        val conversationUpdateSettings: ConversationUpdateSettings = CometChat.getConversationUpdateSettings()
        result.success(conversationUpdateSettings.toMap())
    }

    private fun updateTimezone(call: MethodCall, result: Result){
        val timezoneIdentifier: String = call.argument("timezone") ?: ""

            val timezone = TimeZone.getTimeZone(timezoneIdentifier)
            if (timezone == null) {
                result.error("ERROR", "Invalid timezone", "Invalid timezone identifier received")
                return
            } else {
                CometChatNotifications.updateTimezone(
                    timezone,
                    object : CallbackListener<String>() {

                        override fun onSuccess(response: String) {
                            result.success(response)
                        }

                        override fun onError(e: CometChatException) {
                            result.error(e.code, e.message, e.details)
                        }
                    })
            }


    }

    private fun getTimezone(call: MethodCall, result: Result){
        CometChatNotifications.getTimezone(object : CallbackListener<TimeZone>() {
            override fun onSuccess(response: TimeZone) {
                result.success(response.id)
            }

            override fun onError(e: CometChatException) {
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun createGroupWithMembers(call: MethodCall, result: Result) {
        val guid: String = call.argument("guid") ?: ""
        val owner: String = call.argument("owner") ?: ""
        val name: String = call.argument("name") ?: ""
        val icon: String = call.argument("icon") ?: ""
        val description: String = call.argument("description") ?: ""
        val membersCount: Int = call.argument("membersCount")?: 0
        val createdAt: Long? = call.argument("createdAt")
        val joinedAt: Long? = call.argument("joinedAt")
        val updatedAt: Long? = call.argument("updatedAt")
        val tags: List<String>? = call.argument("tags")
        val type: String = call.argument("type") ?: ""
        val password: String = call.argument("password") ?: ""
        val scope: String = call.argument("scope") ?: ""
        val metadata: String? = call.argument("metadata")
        val groupMembers: List<HashMap<String,Any?>> = call.argument("groupMembers")?: emptyList()
        val bannedUserIds = call.argument<List<String>>("bannedUserIds") ?: emptyList()

        val group = Group()
        if(guid.isNotEmpty())group.guid = guid
        if(owner.isNotEmpty())group.owner = owner
        if(name.isNotEmpty())group.name = name
        if(icon.isNotEmpty())group.icon = icon
        if(description.isNotEmpty())group.description = description
        if(metadata!=null&& metadata.isNotEmpty()){
            group.metadata = JSONObject(metadata)
        }
        if(membersCount!=0) group.membersCount = membersCount
        if(createdAt!=null)group.createdAt = createdAt
        if(joinedAt!=null)group.joinedAt = joinedAt
        if(updatedAt!=null)group.updatedAt = updatedAt
        if(tags!=null) group.tags = tags
        if(type.isNotEmpty())group.groupType = type
        if(password.isNotEmpty())group.password = password
        if(scope.isNotEmpty())group.scope = scope

        val members: MutableList<GroupMember>  = ArrayList()
        for (item in groupMembers){
            members.add(toGroupMember(item))
        }

        CometChat.createGroupWithMembers(
            group,
            members,
            bannedUserIds,
            object : CometChat.CreateGroupWithMembersListener() {
                override fun onSuccess(group: Group, responseMap: HashMap<String?, String?>) {
                    Log.d("createGroupWithMembers", "Group created: ${group.name}")
                    result.success(getGroupMap(group, "createGroupWithMembers"))
                }

                override fun onError(e: CometChatException) {
                    Log.e("createGroupWithMembers", "Error: ${e.message}")
                    result.error(e.code ?: "ERR_UNKNOWN", e.message, e.details)
                }
            }
        )
    }

    private fun getMessageDetails(args: MethodCall, result: Result) {
        val messageId: Long = args.getLongArg("messageId")
        CometChat.getMessageDetails(messageId, object : CometChat.CallbackListener<BaseMessage>() {
            override fun onSuccess(message: BaseMessage) {
                Log.d("getMessageDetails", "Get message details metadata => ${message.metadata}")
                result.success(getMessageMap(message))
            }

            override fun onError(e: CometChatException) {
                Log.e("getMessageDetails", "Get message details failed with exception: ${e.message}")
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun MethodCall.getLongArg(key: String, default: Long = -1L): Long {
        return this.argument<Number>(key)?.toLong() ?: default
    }

    private fun toAttachment(map: Map<String, Any?>): Attachment {
        val attachment = Attachment()
        attachment.fileUrl = map["fileUrl"] as? String
        attachment.fileName = map["fileName"] as? String
        attachment.fileExtension = map["fileExtension"] as? String
        attachment.fileMimeType = map["fileMimeType"] as? String

        map["fileSize"]?.let {
            attachment.fileSize = when (it) {
                is Int -> it
                is Long -> it.toInt()
                is Double -> it.toInt()
                is String -> it.toIntOrNull() ?: 0
                else -> 0
            }
        }

        return attachment
    }

    private fun getModerationStatusValue(status: ModerationStatus?): String {
        return status?.value ?: ModerationStatus.UNMODERATED.value;
    }


    private fun getFlagReasons(args: MethodCall, result: Result) {
        CometChat.getFlagReasons(object : CometChat.CallbackListener<List<FlagReason>>() {

            override fun onSuccess(flagReasons: List<FlagReason>) {
                Log.d("getFlagReasons", "Flag reasons fetched => $flagReasons")

                // Convert list of FlagReason objects to List<Map<String, Any?>>
                val reasonsList = flagReasons.map { reason ->
                    mapOf(
                        "id" to reason.id,
                        "name" to reason.name,
                        "description" to reason.description,
                        "createdAt" to reason.createdAt,
                        "updatedAt" to reason.updatedAt
                    )
                }

                result.success(reasonsList)
            }

            override fun onError(e: CometChatException) {
                Log.e("getFlagReasons", "Failed to fetch reasons: ${e.message}")
                result.error(e.code, e.message, e.details)
            }
        })
    }


    private fun flagMessage(args: MethodCall, result: Result) {
        val messageId: Long = args.getLongArg("messageId")

        // Read the map sent from Flutter
        val reasonMap = args.argument<HashMap<String, Any?>>("reason")

        if (reasonMap == null) {
            result.error("INVALID_ARGUMENT", "Missing 'reason' map", null)
            return
        }

        // Convert Flutter FlagDetail → Native FlagDetail
        val flagDetail = FlagDetail().apply {
            // Flutter "reasonId" → Android "id"
            if (reasonMap["reasonId"] != null) {
                setReasonId(reasonMap["reasonId"] as String)
            }

            // Flutter "remark" → Android "reason"
            if (reasonMap["remark"] != null) {
                setRemark(reasonMap["remark"] as String)
            }
        }

        CometChat.flagMessage(messageId, flagDetail, object : CometChat.CallbackListener<String>() {

            override fun onSuccess(response: String) {
                Log.d("flagMessage", "Message flagged => $response")
                result.success(response)
            }

            override fun onError(e: CometChatException) {
                Log.e("flagMessage", "flagMessage error => ${e.message}")
                result.error(e.code, e.message, e.details)
            }
        })
    }

    private fun markMessageAsUnread(call: MethodCall, result: Result) {
        val baseMessage: HashMap<String, Any?> = call.argument("baseMessage") ?: HashMap()
        var baseMessageObj:BaseMessage = toBaseMessage(baseMessage);
        CometChat.markMessageAsUnread(baseMessageObj, object : CallbackListener<Conversation>() {
            override fun onSuccess(conversation: Conversation) {
                Log.d("markMessageAsUnread", "markMessageAsUnread : " + "success")
                result.success(getConversationMap(conversation))
            }

            override fun onError(e: CometChatException) {
                Log.e("error", "markMessageAsUnread : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun markConversationAsDelivered(call: MethodCall, result: Result) {
        val conversationWithId: String = call.argument("conversationWithId") ?: ""
        val conversationType: String = call.argument("conversationType") ?: ""
        CometChat.markConversationAsDelivered(conversationWithId, conversationType, object : CallbackListener<String>() {
            override fun onSuccess(message: String) {
                Log.d("markConvoAsDelivered", "markConversationAsDelivered : " + "success")
                result.success(message)
            }

            override fun onError(e: CometChatException) {
                Log.e("markConvoAsDelivered", "markConversationAsDelivered : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

    private fun markConversationAsRead(call: MethodCall, result: Result) {
        val conversationWithId: String = call.argument("conversationWithId") ?: ""
        val conversationType: String = call.argument("conversationType") ?: ""
        CometChat.markConversationAsRead(conversationWithId, conversationType, object : CallbackListener<String>() {
            override fun onSuccess(message: String) {
                Log.d("markConversationAsRead", "markConversationAsRead : " + "success")
                result.success(message)
            }

            override fun onError(e: CometChatException) {
                Log.e("markConversationAsRead", "markConversationAsRead : " + e.message)
                result.error(e.code!!, e.message, e.details)
            }
        })
    }

}

