#
# To learn more about a Podspec see http://guides.cocoapods.org/syntax/podspec.html.
# Run `pod lib lint cometchat.podspec' to validate before publishing.
#
Pod::Spec.new do |s|
  s.name             = 'cometchat_sdk'
  s.version          = '4.1.4'
  s.summary          = 'A new flutter plugin project.'
  s.description      = <<-DESC
A new flutter plugin project.
                       DESC
  s.homepage         = 'https://www.cometchat.com/'
  s.license          = { :file => '../LICENSE' }
  s.author           = { 'CometChat' => 'help@cometchat.com' }
  s.source           = { :path => '.' }
  # Sources live under the Swift Package Manager layout so the plugin builds
  # under both CocoaPods and SPM.
  s.source_files = 'cometchat_sdk/Sources/cometchat_sdk/**/*.swift'
  s.dependency 'Flutter'

  # Keep in step with the CometChatSDK version pinned in
  # ios/cometchat_sdk/Package.swift.
  s.dependency 'CometChatSDK', '4.1.3'

  s.platform = :ios, '12.0'

  # Flutter.framework does not contain a i386 slice.
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES', 'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386' }
  s.swift_version = '5.0'

end
