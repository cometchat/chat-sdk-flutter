// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
  name: "cometchat_sdk",
  platforms: [
    .iOS("12.0")
  ],
  products: [
    .library(name: "cometchat-sdk", targets: ["cometchat_sdk"])
  ],
  // FlutterFramework is intentionally not declared: the Flutter tool only
  // generates it from Flutter 3.41, and declaring it breaks SPM builds on
  // Flutter 3.24-3.40.
  dependencies: [],
  targets: [
    .target(
      name: "cometchat_sdk",
      dependencies: [
        "CometChatSDK",
        "CometChatStarscream",
      ]
    ),
    // The native SDK binaries are referenced directly rather than through the
    // github.com/cometchat/chat-sdk-ios package: that repository declares Git
    // LFS attributes, so Xcode refuses to resolve it on machines without
    // git-lfs installed. The URLs and checksums mirror chat-sdk-ios at the tag
    // matching the CometChatSDK pod version in ios/cometchat_sdk.podspec, and
    // must be updated together with it.
    .binaryTarget(
      name: "CometChatSDK",
      url: "https://dl.cloudsmith.io/public/cometchat/cometchat/raw/versions/4.1.10/CometChatSDK_4_1_10.xcframework.zip",
      checksum: "76e9e0fbb0da54427df8f773f0f3512bdf46f0d031c6d69d930dc835d4787a04"
    ),
    .binaryTarget(
      name: "CometChatStarscream",
      url: "https://library.cometchat.io/ios/v4.0/xcode15/CometChatStarscream_1_0_2.xcframework.zip",
      checksum: "94fef289d5b952bb06465e7631be83b40594072931a580a9e8ba86258b9f0ec5"
    ),
  ]
)
