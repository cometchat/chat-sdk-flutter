#import <Flutter/Flutter.h>

@interface CometchatPlugin : NSObject<FlutterPlugin>
@end
