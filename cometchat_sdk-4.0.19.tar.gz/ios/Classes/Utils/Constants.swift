//
//  Constants.swift
//  Pods
//
//  Created by Nabhodipta Garai on 14/01/25.
//

class BaseMessageConstants {
    static let baseMessage = "baseMessage"
    static let receiverType = "receiverType"
    static let sender = "sender"
    static let receiver = "receiver"
    static let receiverUid = "receiverUid"
    static let type = "type"
    static let id = "id"
    static let tags = "tags"
    static let metadata = "metadata"
    static let category = "category"
    
    
}

class MediaMessageConstants: BaseMessageConstants {
    static let file = "file"
    static let attachment = "attachment"
    static let fileUrl = "fileUrl"
}

class UserConstants {
    static let name = "name"
    static let uid = "uid"
}

class GroupConstants {
    static let name = "name"
    static let guid = "guid"
}

class MessageTypeConstants{
    static let text = "text"
    static let image = "image"
    static let video = "video"
    static let audio = "audio"
    static let file = "file"
}

class MessageCategoryConstants{
    static let message = "message"
    static let custom = "custom"
}
