package com.cometchat.cometchat_sdk


object BaseMessageConstants{
    const val baseMessage = "baseMessage"
    const val type = "type"
    const val category = "category"
}

 object MediaMessageConstants {
        const val receiverType = "receiverType"
        const val sender = "sender"
        const val receiver = "receiver"
        const val receiverUid = "receiverUid"
        const val type = "type"
        const val id = "id"
        const val tags = "tags"
        const val metadata = "metadata"
        const val parentMessageId = "parentMessageId"
        const val category = "category"
    }


