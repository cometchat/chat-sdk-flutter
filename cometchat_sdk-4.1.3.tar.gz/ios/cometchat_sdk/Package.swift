// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
  name: "cometchat_sdk",
  platforms: [
    .iOS("12.0")
  ],
  products: [
    .library(name: "cometchat-sdk", targets: ["cometchat_sdk"])
  ],
  dependencies: [
    // Supplied by the Flutter tool when it generates the app's SPM workspace.
    .package(name: "FlutterFramework", path: "../FlutterFramework"),
    // Must stay pinned to the same version as the CometChatSDK pod in
    // ios/cometchat_sdk.podspec, so CocoaPods and SPM builds resolve the same
    // native SDK.
    .package(url: "https://github.com/cometchat/chat-sdk-ios.git", exact: "4.1.3"),
  ],
  targets: [
    .target(
      name: "cometchat_sdk",
      dependencies: [
        .product(name: "FlutterFramework", package: "FlutterFramework"),
        .product(name: "CometChatSDK", package: "chat-sdk-ios"),
      ]
    )
  ]
)
