class FlagDetail {
  String reasonId;
  String? remark;

  /// Constructs a new [FlagDetail] instance.
  FlagDetail({
    required this.reasonId,
    this.remark,
  });

  /// Creates a new [FlagDetail] instance from a map.
  factory FlagDetail.fromMap(dynamic map) {
    if (map == null) {
      throw ArgumentError('The type of FlagDetail map is null');
    }
    return FlagDetail(
      reasonId: map['reasonId'],
      remark: map['remark'],
    );
  }

  /// Generates a map representing the [FlagDetail].
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['reasonId'] = reasonId;
    map['remark'] = remark;

    return map;
  }

  /// Generates a map representing the [FlagDetail].
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{};
    map['reasonId'] = reasonId;
    map['remark'] = remark;
    return map;
  }

  /// Returns a string representation of the [FlagDetail] instance.
  @override
  String toString() {
    return 'FlagDetail{reasonId: $reasonId, remark: $remark}';
  }
}
