class FlagReason {
  String id;
  String name;
  String? description;
  DateTime? createdAt;
  DateTime? updatedAt;

  /// Constructs a new [FlagReason] instance.
  FlagReason({
    required this.id,
    required this.name,
    this.description,
    this.createdAt,
    this.updatedAt,
  });

  /// Creates a new [FlagReason] instance from a map.
  factory FlagReason.fromMap(dynamic map) {
    if (map == null) {
      throw ArgumentError('The type of flagReason map is null');
    }
    return FlagReason(
      id: map['id'],
      name: map['name'],
      description: map['description'],
      createdAt: map['createdAt'] == 0 || map['createdAt'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['createdAt'] * 1000),
      updatedAt: map['updatedAt'] == 0 || map['updatedAt'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['updatedAt'] * 1000),
    );
  }

  /// Generates a map representing the [FlagReason].
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['description'] = description;
    map['createdAt'] = createdAt == null ? 0 : createdAt;
    map['updatedAt'] = updatedAt == null ? 0 : updatedAt;

    return map;
  }

  /// Generates a map representing the [FlagReason].
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['description'] = description;
    map['createdAt'] = createdAt;
    map['updatedAt'] = updatedAt;
    return map;
  }

  /// Returns a string representation of the [FlagReason] instance.
  @override
  String toString() {
    return 'FlagReason{id: $id, name: $name, description: $description, createdAt: $createdAt, updatedAt: $updatedAt}';
  }
}
