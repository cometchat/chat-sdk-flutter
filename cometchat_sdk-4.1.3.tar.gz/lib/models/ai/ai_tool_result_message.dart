import 'dart:convert';
import '../../cometchat_sdk.dart';

/// Represents a tool result message in AI Assistant.
///
/// Extends [BaseMessage] and adds properties specific to tool results.
class AIToolResultMessage extends BaseMessage {
  int? runId;
  String? threadId;
  String? text;
  String? toolCallId;
  List<String>? tags;

  AIToolResultMessage({
    this.runId,
    this.threadId,
    this.text,
    this.toolCallId,
    this.tags,
    int id = 0,
    String muid = '',
    User? sender,
    AppEntity? receiver,
    required String receiverUid,
    required String type,
    required String receiverType,
    String category = CometChatMessageCategory.categoryAgentic,
    DateTime? sentAt,
    DateTime? deliveredAt,
    DateTime? readAt,
    Map<String, dynamic>? metadata,
    DateTime? readByMeAt,
    DateTime? deliveredToMeAt,
    DateTime? deletedAt,
    DateTime? editedAt,
    String? deletedBy,
    String? editedBy,
    DateTime? updatedAt,
    String? conversationId,
    int parentMessageId = 0,
    int replyCount = 0,
    int unreadRepliesCount = 0,
    List<User>? mentionedUsers,
    bool? hasMentionedMe,
    List<ReactionCount>? reactions,
    BaseMessage? quotedMessage,
    int? quotedMessageId,
  }) : super(
            id: id,
            muid: muid,
            sender: sender,
            receiver: receiver,
            receiverUid: receiverUid,
            type: type,
            receiverType: receiverType,
            category: category,
            sentAt: sentAt,
            deliveredAt: deliveredAt,
            readAt: readAt,
            metadata: metadata,
            readByMeAt: readByMeAt,
            deliveredToMeAt: deliveredToMeAt,
            deletedAt: deletedAt,
            editedAt: editedAt,
            deletedBy: deletedBy,
            editedBy: editedBy,
            updatedAt: updatedAt,
            conversationId: conversationId,
            parentMessageId: parentMessageId,
            replyCount: replyCount,
            unreadRepliesCount: unreadRepliesCount,
            mentionedUsers: mentionedUsers ?? [],
            reactions: reactions ?? [],
            hasMentionedMe: hasMentionedMe,
            quotedMessage: quotedMessage,
            quotedMessageId: quotedMessageId);

  /// Creates an instance from a map.
  factory AIToolResultMessage.fromMap(dynamic map, {AppEntity? receiver}) {
    if (map == null) {
      throw ArgumentError('The AIToolResultMessage map is null');
    }

    final appEntity = (map['receiver'] == null)
        ? receiver
        : (map['receiverType'] == CometChatReceiverType.user)
            ? User.fromMap(map['receiver'])
            : Group.fromMap(map['receiver']);

    final conversationId = (map['conversationId'] == null ||
            (map['conversationId'] as String).isEmpty)
        ? map['receiverType'] == CometChatReceiverType.user
            ? '${map['sender']?['uid']}_user_${(appEntity as User).uid}'
            : 'group_${map['receiver']['guid']}'
        : map['conversationId'];

    return AIToolResultMessage(
      runId: map['runId'],
      threadId: map['threadId'],
      text: map['text'],
      toolCallId: map['toolCallId'],
      tags: (map['tags'] != null) ? List<String>.from(map['tags']) : null,
      id: map['id'] ?? 0,
      muid: map['muid'] ?? '',
      sender: map['sender'] != null ? User.fromMap(map['sender']) : null,
      receiver: appEntity,
      receiverUid: map['receiverUid'] ?? '',
      type: map['type'] ?? CometChatMessageType.assistant,
      receiverType: map['receiverType'] ?? '',
      category: map['category'] ?? CometChatMessageCategory.categoryAgentic,
      sentAt: map['sentAt'] == null || map['sentAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['sentAt'] * 1000),
      deliveredAt: map['deliveredAt'] == null || map['deliveredAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['deliveredAt'] * 1000),
      readAt: map['readAt'] == null || map['readAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['readAt'] * 1000),
      metadata: map['metadata'] == null
          ? {}
          : Map<String, dynamic>.from(map['metadata'] is String
              ? json.decode(map['metadata'])
              : map['metadata']),
      readByMeAt: map['readByMeAt'] == null || map['readByMeAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['readByMeAt'] * 1000),
      deliveredToMeAt: map['deliveredToMeAt'] == null ||
              map['deliveredToMeAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['deliveredToMeAt'] * 1000),
      deletedAt: map['deletedAt'] == null || map['deletedAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['deletedAt'] * 1000),
      editedAt: map['editedAt'] == null || map['editedAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['editedAt'] * 1000),
      deletedBy: map['deletedBy'],
      editedBy: map['editedBy'],
      updatedAt: map['updatedAt'] == null || map['updatedAt'] == 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['updatedAt'] * 1000),
      conversationId: conversationId,
      parentMessageId: map['parentMessageId'] ?? 0,
      replyCount: map['replyCount'] ?? 0,
      unreadRepliesCount: map['unreadRepliesCount'] ?? 0,
      mentionedUsers: map['mentionedUsers'] != null
          ? (map['mentionedUsers'] as List).map((e) => User.fromMap(e)).toList()
          : [],
      hasMentionedMe: map['hasMentionedMe'] ?? false,
      reactions: map['reactions'] != null
          ? (map['reactions'] as List)
              .map((e) => ReactionCount.fromMap(e))
              .toList()
          : [],
      quotedMessageId: map['quotedMessageId'],
      quotedMessage: (map['quotedMessage'] != null)
          ? BaseMessage.fromMap(map['quotedMessage'])
          : null,
    );
  }

  /// Converts the object to a map.
  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();

    map['runId'] = runId;
    map['threadId'] = threadId;
    map['text'] = text;
    map['toolCallId'] = toolCallId;
    map['tags'] = tags ?? [];
    map['quotedMessageId'] = quotedMessageId;
    if (quotedMessage != null) {
      map['quotedMessage'] = quotedMessage!.toJson();
    }
    return map;
  }

  @override
  String toString() {
    return 'AIToolResultMessage{runId: $runId, threadId: $threadId, text: $text, toolCallId: $toolCallId, tags: $tags}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AIToolResultMessage &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}
