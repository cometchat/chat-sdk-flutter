import '../../cometchat_sdk.dart';

class AIAssistantBaseEvent {
  int? id;
  String? type;
  String? conversationId;
  String? parentId;
  Map<String, dynamic>? additionalProperties;

  AIAssistantBaseEvent({
    this.id,
    this.type,
    this.conversationId,
    this.parentId,
    this.additionalProperties,
  });

  /// Creates a new instance from a map
  factory AIAssistantBaseEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) {
      throw ArgumentError('The AI Assistant base event map is empty');
    }

    // If the 'type' key is actually a map, unwrap it
    if (map['type'] is Map) {
      map = Map<String, dynamic>.from(map['type']);
    }

    return AIAssistantBaseEvent(
      id: map['id'] is int
          ? map['id']
          : int.tryParse(map['id']?.toString() ?? ''),
      type: map['type'] is String ? map['type'] : map['type']?.toString(),
      conversationId: map['conversationId'] is String
          ? map['conversationId']
          : map['conversationId']?.toString(),
      parentId: map['parentId'] is String
          ? map['parentId']
          : map['parentId']?.toString(),
      additionalProperties: map['additionalProperties'] is Map
          ? Map<String, dynamic>.from(map['additionalProperties'])
          : {},
    );
  }

  /// Converts the object to a map
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['type'] = type;
    map['conversationId'] = conversationId;
    map['parentId'] = parentId;
    if (additionalProperties != null && additionalProperties!.isNotEmpty) {
      map['additionalProperties'] = additionalProperties;
    }
    return map;
  }

  /// Factory to process event type dynamically
  static AIAssistantBaseEvent? processEvent(
      Map<String, dynamic>? map, String? eventType) {
    if (map == null || map.isEmpty) return null;

    final normalizedType = eventType?.toLowerCase();

    switch (normalizedType) {
      case AgenticKeys.runStarted:
      case AgenticKeys.textMessageStart:
        return AIAssistantRunStartedEvent.fromMap(map);
      case AgenticKeys.textMessageContent:
        return AIAssistantContentReceivedEvent.fromMap(map);
      case AgenticKeys.textMessageEnd:
        return AIAssistantMessageEndedEvent.fromMap(map);
      case AgenticKeys.runFinished:
        return AIAssistantRunFinishedEvent.fromMap(map);
      case AgenticKeys.toolCallStart:
        return AIAssistantToolStartedEvent.fromMap(map);
      case AgenticKeys.toolCallEnd:
        return AIAssistantToolEndedEvent.fromMap(map);
      case AgenticKeys.toolCallResult:
        return AIAssistantToolResultEvent.fromMap(map);
      case AgenticKeys.toolCallArgs:
        return AIAssistantToolArgumentEvent.fromMap(map);
      default:
        print('Unknown AI Assistant event type: $eventType');
        return null;
    }
  }
}
