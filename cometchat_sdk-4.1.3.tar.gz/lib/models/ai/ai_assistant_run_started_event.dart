import '../../cometchat_sdk.dart';

/// Represents an event when an AI Assistant run has started.
///
/// Extends [AIAssistantBaseEvent] and includes run-specific data.
class AIAssistantRunStartedEvent extends AIAssistantBaseEvent {
  int? runId;
  String? threadId;
  String? streamMessageId;
  String? role;

  AIAssistantRunStartedEvent({
    this.runId,
    this.threadId,
    this.streamMessageId,
    this.role,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
          id: id,
          type: type,
          conversationId: conversationId,
          parentId: parentId,
          additionalProperties: additionalProperties,
        );

  /// Creates an instance from a map.
  factory AIAssistantRunStartedEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) {
      throw ArgumentError('The AI Assistant run started event map is empty');
    }

    final base = AIAssistantBaseEvent.fromMap(map);

    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantRunStartedEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      runId: data['runId'] is int
          ? data['runId']
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId']?.toString(),
      streamMessageId: data['streamMessageId']?.toString(),
      role: data['role']?.toString(),
    );
  }

  /// Converts the object to a map.
  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'runId': runId,
      'threadId': threadId,
      'streamMessageId': streamMessageId,
      'role': role,
    };
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantRunStartedEvent{runId: $runId, threadId: $threadId, streamMessageId: $streamMessageId, role: $role}';
  }
}
