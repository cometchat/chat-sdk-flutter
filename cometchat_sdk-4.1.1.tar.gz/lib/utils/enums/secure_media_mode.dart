/// Defines the mode for secure media access.
///
/// This enum controls how FAT (File Access Token) is transmitted when
/// loading media from secure CometChat servers.
enum SecureMediaMode {
  /// Embedded mode - FAT token appended to URL as query parameter.
  /// This is the default mode for backward compatibility.
  /// Example URL: https://files-us.cometchat.io/image.jpg?fat=abc123
  embedded('embedded'),

  /// Header-based mode - FAT token sent via HTTP header.
  /// URLs are clean without FAT query parameter.
  /// Example URL: https://files-us.cometchat.io/image.jpg
  /// HTTP Header: fat: abc123
  headerBased('headerBased');

  final String value;

  const SecureMediaMode(this.value);

  @override
  String toString() => value;

  static SecureMediaMode? fromValue(String value) {
    try {
      return SecureMediaMode.values.firstWhere((e) => e.value == value);
    } catch (_) {
      return null;
    }
  }
}
