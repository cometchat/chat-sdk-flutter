import '../cometchat_sdk.dart';

mixin AIAssistantListener implements EventHandler {
  void onAIAssistantEventReceived(AIAssistantBaseEvent aiAssistantBaseEvent) {}
}
