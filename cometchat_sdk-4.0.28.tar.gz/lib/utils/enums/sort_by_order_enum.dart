enum SortByOrderEnum {
  ASC('asc'),
  DESC('desc');

  final String value;

  const SortByOrderEnum(this.value);

  @override
  String toString() => value;

  static SortByOrderEnum? fromValue(String value) {
    try {
      return SortByOrderEnum.values.firstWhere((e) => e.value == value);
    } catch (_) {
      return null;
    }
  }
}
