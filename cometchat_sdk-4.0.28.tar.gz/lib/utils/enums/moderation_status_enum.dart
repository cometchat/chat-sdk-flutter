enum ModerationStatusEnum {
  UNMODERATED('unmoderated'),
  PENDING('pending'),
  APPROVED('approved'),
  DISAPPROVED('disapproved');

  final String value;

  const ModerationStatusEnum(this.value);

  @override
  String toString() => value;

  static ModerationStatusEnum? fromValue(String value) {
    try {
      return ModerationStatusEnum.values.firstWhere((e) => e.value == value);
    } catch (_) {
      return null;
    }
  }
}
