enum AttachmentType {
  IMAGE('image'),
  VIDEO('video'),
  AUDIO('audio'),
  FILE('file');

  final String value;

  const AttachmentType(this.value);

  @override
  String toString() => value;

  static AttachmentType? fromValue(String value) {
    try {
      return AttachmentType.values.firstWhere((e) => e.value == value);
    } catch (_) {
      return null;
    }
  }
}
