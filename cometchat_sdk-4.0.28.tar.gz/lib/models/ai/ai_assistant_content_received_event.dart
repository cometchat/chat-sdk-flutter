import '../../cometchat_sdk.dart';

class AIAssistantContentReceivedEvent extends AIAssistantBaseEvent {
  String? streamMessageId;
  int? runId;
  String? threadId;
  String? delta;

  AIAssistantContentReceivedEvent({
    this.streamMessageId,
    this.runId,
    this.threadId,
    this.delta,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
          id: id,
          type: type,
          conversationId: conversationId,
          parentId: parentId,
          additionalProperties: additionalProperties,
        );

  factory AIAssistantContentReceivedEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) throw ArgumentError('Event map is empty');
    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantContentReceivedEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      streamMessageId: data['streamMessageId']?.toString(),
      runId: data['runId'] is int
          ? data['runId']
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId']?.toString(),
      delta: data['delta']?.toString(),
    );
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'streamMessageId': streamMessageId,
      'runId': runId,
      'threadId': threadId,
      'delta': delta,
    };
    return map;
  }
}
