import '../../cometchat_sdk.dart';

/// Represents an AI Assistant tool argument event.
///
/// Extends [AIAssistantBaseEvent] and includes tool call specific data.
class AIAssistantToolArgumentEvent extends AIAssistantBaseEvent {
  int? runId;
  String? threadId;
  String? toolCallId;
  String? delta;
  String? toolCallName;
  String? displayName;
  String? executionText;
  String? arguments;

  AIAssistantToolArgumentEvent({
    this.runId,
    this.threadId,
    this.toolCallId,
    this.delta,
    this.toolCallName,
    this.displayName,
    this.executionText,
    this.arguments,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
    id: id,
    type: type,
    conversationId: conversationId,
    parentId: parentId,
    additionalProperties: additionalProperties,
  );

  factory AIAssistantToolArgumentEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) throw ArgumentError('Event map is empty');
    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantToolArgumentEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      runId: data['runId'] is int
          ? data['runId']
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId']?.toString(),
      toolCallId: data['toolCallId']?.toString(),
      delta: data['delta']?.toString(),
      toolCallName: data['toolCallName']?.toString(),
      displayName: data['displayName']?.toString(),
      executionText: data['executionText']?.toString(),
      arguments: data['arguments']?.toString(),
    );
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'runId': runId,
      'threadId': threadId,
      'toolCallId': toolCallId,
      'delta': delta,
      'toolCallName': toolCallName,
      'displayName': displayName,
      'executionText': executionText,
      'arguments': arguments,
    };
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantToolArgumentEvent{runId: $runId, threadId: $threadId, toolCallId: $toolCallId, delta: $delta, toolCallName: $toolCallName, displayName: $displayName, executionText: $executionText, arguments: $arguments}';
  }
}
