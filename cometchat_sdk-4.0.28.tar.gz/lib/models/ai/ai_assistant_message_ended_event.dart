import '../../cometchat_sdk.dart';

/// Represents an event when an AI Assistant message has ended.
///
/// Extends [AIAssistantBaseEvent] and includes event-specific data.
class AIAssistantMessageEndedEvent extends AIAssistantBaseEvent {
  String? eventType;
  String? messageId;
  int? runId;
  String? threadId;
  String? streamMessageId;

  AIAssistantMessageEndedEvent({
    this.eventType,
    this.messageId,
    this.runId,
    this.threadId,
    this.streamMessageId,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
    id: id,
    type: type,
    conversationId: conversationId,
    parentId: parentId,
    additionalProperties: additionalProperties,
  );

  factory AIAssistantMessageEndedEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) throw ArgumentError('Event map is empty');
    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantMessageEndedEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      eventType: data['type']?.toString(),
      messageId: data['messageId']?.toString(),
      runId: data['runId'] is int ? data['runId'] : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId']?.toString(),
      streamMessageId: data['streamMessageId']?.toString(),
    );
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'type': eventType,
      'messageId': messageId,
      'runId': runId,
      'threadId': threadId,
      'streamMessageId': streamMessageId,
    };
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantMessageEndedEvent{eventType: $eventType, messageId: $messageId, runId: $runId, threadId: $threadId, streamMessageId: $streamMessageId}';
  }
}
