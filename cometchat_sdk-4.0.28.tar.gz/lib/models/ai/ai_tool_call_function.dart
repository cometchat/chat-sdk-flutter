/// Represents a function call associated with an AI tool call.
class AIToolCallFunction {
  String? name;
  String? arguments;

  AIToolCallFunction({this.name, this.arguments});

  /// Creates an instance from a map.
  factory AIToolCallFunction.fromMap(Map<String, dynamic> map) {
    return AIToolCallFunction(
      name: map['name'],
      arguments: map['arguments'],
    );
  }

  /// Converts this object to a map for JSON serialization.
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (name != null) {
      map['name'] = name;
    }
    if (arguments != null) {
      map['arguments'] = arguments;
    }
    return map;
  }

  @override
  String toString() {
    return 'AIToolCallFunction{name: $name, arguments: $arguments}';
  }
}
