import '../../cometchat_sdk.dart';

/// Represents an AI Assistant tool result event.
///
/// Extends [AIAssistantBaseEvent] and includes result-specific data.
class AIAssistantToolResultEvent extends AIAssistantBaseEvent {
  String? streamMessageId;
  int? runId;
  String? threadId;
  String? toolCallId;
  String? content;
  String? role;
  String? toolCallName;
  String? displayName;
  String? executionText;
  String? arguments;

  AIAssistantToolResultEvent({
    this.streamMessageId,
    this.runId,
    this.threadId,
    this.toolCallId,
    this.content,
    this.role,
    this.toolCallName,
    this.displayName,
    this.executionText,
    this.arguments,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
          id: id,
          type: type,
          conversationId: conversationId,
          parentId: parentId,
          additionalProperties: additionalProperties,
        );

  /// Creates an instance from a map (similar to Android's fromJson).
  factory AIAssistantToolResultEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) {
      throw ArgumentError('The AI Assistant tool result event map is empty');
    }

    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantToolResultEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      streamMessageId: data['streamMessageId'] as String?,
      runId: (data['runId'] is int)
          ? data['runId'] as int
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId'] as String?,
      toolCallId: data['toolCallId'] as String?,
      content: data['content'] as String?,
      role: data['role'] as String?,
      toolCallName: data['toolCallName'] as String?,
      displayName: data['displayName'] as String?,
      executionText: data['executionText'] as String?,
      arguments: data['arguments'] as String?,
    );
  }

  /// Converts the object to a map (similar to Android's toJson).
  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'streamMessageId': streamMessageId,
      'runId': runId,
      'threadId': threadId,
      'toolCallId': toolCallId,
      'content': content,
      'role': role,
      'toolCallName': toolCallName,
      'displayName': displayName,
      'executionText': executionText,
      'arguments': arguments,
    };
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantToolResultEvent{streamMessageId: $streamMessageId, runId: $runId, threadId: $threadId, toolCallId: $toolCallId, content: $content, role: $role, toolCallName: $toolCallName, displayName: $displayName, executionText: $executionText, arguments: $arguments}';
  }
}
