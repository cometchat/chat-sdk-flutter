import '../../cometchat_sdk.dart';

/// Represents an event when an AI Assistant run has finished.
///
/// Extends [AIAssistantBaseEvent] and includes run-specific data.
class AIAssistantRunFinishedEvent extends AIAssistantBaseEvent {
  int? runId;
  String? threadId;

  AIAssistantRunFinishedEvent({
    this.runId,
    this.threadId,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
    id: id,
    type: type,
    conversationId: conversationId,
    parentId: parentId,
    additionalProperties: additionalProperties,
  );

  factory AIAssistantRunFinishedEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) {
      throw ArgumentError('The AI Assistant run finished event map is empty');
    }
    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantRunFinishedEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      runId: data['runId'] is int
          ? data['runId']
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId']?.toString(),
    );
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {'runId': runId, 'threadId': threadId};
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantRunFinishedEvent{runId: $runId, threadId: $threadId}';
  }
}
