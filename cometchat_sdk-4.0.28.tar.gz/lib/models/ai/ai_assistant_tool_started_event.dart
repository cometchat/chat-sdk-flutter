import '../../cometchat_sdk.dart';

/// Represents an AI Assistant tool started event.
///
/// Extends [AIAssistantBaseEvent] and includes tool call specific data.
class AIAssistantToolStartedEvent extends AIAssistantBaseEvent {
  String? streamParentMessageId;
  int? runId;
  String? threadId;
  String? toolCallId;
  String? toolCallName;
  String? displayName;
  String? executionText;
  String? arguments;

  AIAssistantToolStartedEvent({
    this.streamParentMessageId,
    this.runId,
    this.threadId,
    this.toolCallId,
    this.toolCallName,
    this.displayName,
    this.executionText,
    this.arguments,
    int? id,
    String? type,
    String? conversationId,
    String? parentId,
    Map<String, dynamic>? additionalProperties,
  }) : super(
          id: id,
          type: type,
          conversationId: conversationId,
          parentId: parentId,
          additionalProperties: additionalProperties,
        );

  /// Creates an instance from a map.
  factory AIAssistantToolStartedEvent.fromMap(Map<String, dynamic> map) {
    if (map.isEmpty) {
      throw ArgumentError('The AI Assistant tool started event map is empty');
    }

    final base = AIAssistantBaseEvent.fromMap(map);
    final data = Map<String, dynamic>.from(map['data'] ?? <String, dynamic>{});

    return AIAssistantToolStartedEvent(
      id: base.id,
      type: base.type,
      conversationId: base.conversationId,
      parentId: base.parentId,
      additionalProperties: base.additionalProperties,
      streamParentMessageId: data['streamParentMessageId'] as String?,
      runId: data['runId'] is int
          ? data['runId']
          : int.tryParse(data['runId']?.toString() ?? ''),
      threadId: data['threadId'] as String?,
      toolCallId: data['toolCallId'] as String?,
      toolCallName: data['toolCallName'] as String?,
      displayName: data['displayName'] as String?,
      executionText: data['executionText'] as String?,
      arguments: data['arguments'] as String?,
    );
  }

  /// Converts the object to a map.
  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['data'] = {
      'streamParentMessageId': streamParentMessageId,
      'runId': runId,
      'threadId': threadId,
      'toolCallId': toolCallId,
      'toolCallName': toolCallName,
      'displayName': displayName,
      'executionText': executionText,
      'arguments': arguments,
    };
    return map;
  }

  @override
  String toString() {
    return 'AIAssistantToolStartedEvent{streamParentMessageId: $streamParentMessageId, runId: $runId, threadId: $threadId, toolCallId: $toolCallId, toolCallName: $toolCallName, displayName: $displayName, executionText: $executionText, arguments: $arguments}';
  }
}
