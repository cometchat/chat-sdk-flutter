import '../../cometchat_sdk.dart';

/// Represents a tool call used in AI Assistant messages.
class AIToolCall {
  String? id;
  String? type;
  String? displayName;
  String? executionText;
  AIToolCallFunction? function;

  AIToolCall({
    this.id,
    this.type,
    this.displayName,
    this.executionText,
    this.function,
  });

  /// Creates an instance from a map.
  factory AIToolCall.fromMap(Map<String, dynamic> map) {
    return AIToolCall(
      id: map['id'],
      type: map['type'],
      displayName: map['displayName'],
      executionText: map['executionText'],
      function: map['function'] != null
          ? AIToolCallFunction.fromMap(
              Map<String, dynamic>.from(map['function']))
          : null,
    );
  }

  /// Converts this object to a map for JSON serialization.
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (id != null) {
      map['id'] = id;
    }
    if (type != null) {
      map['type'] = type;
    }
    if (displayName != null) {
      map['displayName'] = displayName;
    }
    if (executionText != null) {
      map['executionText'] = executionText;
    }
    if (function != null) {
      map['function'] = function!.toJson();
    }
    return map;
  }

  @override
  String toString() {
    return 'AIToolCall{id: $id, type: $type, displayName: $displayName, executionText: $executionText, function: $function}';
  }
}
