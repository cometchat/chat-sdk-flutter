# highlight.js

Generated from https://highlightjs.org/download/ on 2021-07-13

**Included languages:**

* bash
* c  
* css
* dart
* diff
* html, xml
* java
* javascript
* json
* kotlin
* markdown
* objective-c
* plaintext  
* shell
* swift
* yaml
